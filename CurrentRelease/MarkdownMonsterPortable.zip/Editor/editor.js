/// <reference path="editorSettings.js"/>
/// <reference path="editor-helpers.js"/>

(function () {
    "use strict";

    const previewRefreshDelay = 100;
    const defaultPreviewRefreshTimeout = 275;
    const defaultPreviewRefreshTimeoutSlow = 800;
    const defaultPreviewScrollTimeout = 750;
    const monacoRef = () => window.monaco;

    const te = window.textEditor = {
        mm: null,
        mmAsync: null,

        isEditorSimple: true,
        isReady: false,
        isInitializing: false,
        pendingOperations: [],
        settings: editorSettings,
        lastStyle: null,

        editorElement: null,
        editorRoot: null,
        pane1: null,
        pane2: null,
        surface1: null,
        surface2: null,

        mainEditor: null,
        editor2: null,
        editor: null,
        model: null,
        splitMode: "None",
        isDiffMode: false,
        isRecoveryMode: false,
        recoveryBar: null,
        recoveryOriginalText: null,
        diffViewMode: "Inline",
        diffEditor: null,
        diffOriginalModel: null,
        diffSnapshot: null,
        diffContextMenuTarget: null,
        diffToolbarActionsRegistered: false,
        registeredMonacoCommands: {},

        previewRefreshTimeout: defaultPreviewRefreshTimeout,
        previewRefreshTimeoutSlow: defaultPreviewRefreshTimeoutSlow,
        previewScrollTimeout: defaultPreviewScrollTimeout,
        noRefreshPreview: false,
        noRefreshPreviewTimer: null,
        codeScrolled: 0,

        isDirty: false,
        mousePos: { column: 0, row: 0 },
        lastContextMenuPos: null,
        lastError: null,

        _changeCount: 0,
        _redoCount: 0,
        _isUndoRedoOperation: false,
        _suppressUndoTracking: false,
        wheelZoomInFlight: false,
        wheelZoomQueuedDirection: 0,       

        spellcheckEnabled: true,
        spellcheckDictionary: "en-US",
        spellcheckWords: [],
        spellcheckDecorationIds: [],
        spellcheckRunning: false,
        spellcheckTimer: null,
        spellcheckContentModified: true,
        spellcheckMarkerOwner: "mm-spellcheck",
        spellcheckUseMonacoAssist: !!editorSettings.enableMonacoSpellcheckAssist,
        spellcheckExcludedWords: ",body,html,xml,div,span,td,th,tr,thead,tbody,blockquote,src,href,ul,ol,li,png,gif,jpg,js,css,htm,html,topiclink,lang,img,&nbsp;,http,https,www,com,br,nbsp,---,--,startuml,enduml,",

        ghostText: null,
        ghostTextContent: "",
        ghostTextPosition: null,
        ghostWidget: null,
        ghostZoneId: null,
        ghostZoneEditor: null,

        hostBindings: [],
        hostBindingLookup: {},

        disposerBag: [],
        languageExtensionsReadyPromise: null,
        themeDefinitionsReadyPromise: null,

        keyBindings: {
            setupKeyBindings: function () {
                te.setupHostKeyBindings();
            },
            nextSpellCheckError: function () {
                te.spellcheckNext();
            },
            previousSpellCheckError: function () {
                te.spellcheckPrevious();
            }
        },

        spellcheck: {
            spellCheck: function (force) {
                te.spellcheckDocument(force);
            }
        },

        setCodeScrolled: function () {
            te.codeScrolled = Date.now();
        },
        suspendPreviewRefresh: function (timeout) {
            te.noRefreshPreview = true;
            te.setCodeScrolled();

            if (te.noRefreshPreviewTimer) {
                clearTimeout(te.noRefreshPreviewTimer);
            }

            te.noRefreshPreviewTimer = setTimeout(function () {
                te.noRefreshPreview = false;
                te.noRefreshPreviewTimer = null;
            }, timeout || te.previewScrollTimeout);
        },
        isCodeScrolled: function (timeout) {
            const limit = timeout || te.previewScrollTimeout;
            return te.codeScrolled && te.codeScrolled > Date.now() - limit;
        },

        initialize: function (styleSettings) {
            if (styleSettings) {
                te.settings = styleSettings;
            }

            te.isInitializing = true;
            te.editorElement = document.getElementById("Editor");
            te.ensureMonacoReady()
                .then(function () {
                    return te.ensureLanguageExtensionsReady();
                })
                .then(function () {
                    return te.ensureThemeDefinitionsReady();
                })
                .then(function () {
                    const registrations = [];
                    if (window.mmMonacoLanguageExtensions &&
                        typeof window.mmMonacoLanguageExtensions.register === "function") {
                        registrations.push(Promise.resolve(window.mmMonacoLanguageExtensions.register(te, monacoRef)));
                    }
                    if (window.mmMonacoThemes &&
                        typeof window.mmMonacoThemes.register === "function") {
                        registrations.push(Promise.resolve(window.mmMonacoThemes.register(monacoRef)));
                    }

                    if (registrations.length < 1) {
                        return null;
                    }

                    return Promise.all(registrations);
                })
                .then(function () {
                    te.registerDiffHunkToolbarActions();
                    te.ensureEditorLayout();
                    te.createOrResetEditors(te.settings);
                    te.configureEvents();
                    te.setEditorStyle(te.settings);
                    te.setupHostKeyBindings();
                    te.isReady = true;
                    te.isInitializing = false;
                    te.flushPendingOperations();

                    // KeyCode.Enter handler
                    if (te.settings.enableListAutoCompletion)
                        installMarkdownListContinuation(te.editor);                    
                })
                .catch(function (error) {
                    te.isInitializing = false;
                    te.isReady = false;
                    te.lastError = "Monaco initialization failed: " + (error && error.message ? error.message : error);
                    if (console && console.error) {
                        console.error(te.lastError);
                    }
                    status(te.lastError);
                });
        },
        ensureMonacoReady: function () {
            if (window.__monacoReadyPromise) {
                return window.__monacoReadyPromise;
            }

            if (window.monaco) {
                return Promise.resolve(window.monaco);
            }

            return Promise.reject(new Error("Monaco loader was not initialized."));
        },
        ensureLanguageExtensionsReady: function () {
            if (window.mmMonacoLanguageExtensions &&
                typeof window.mmMonacoLanguageExtensions.register === "function") {
                return Promise.resolve(window.mmMonacoLanguageExtensions);
            }

            if (te.languageExtensionsReadyPromise) {
                return te.languageExtensionsReadyPromise;
            }

            te.languageExtensionsReadyPromise = new Promise(function (resolve) {
                const complete = function () {
                    resolve(window.mmMonacoLanguageExtensions || null);
                };

                const existingScript = document.querySelector("script[data-mm-monaco-language-extensions='true'],script[src$='editor-monaco-language-extensions.js']");
                if (existingScript) {
                    if (window.mmMonacoLanguageExtensions) {
                        complete();
                        return;
                    }

                    existingScript.addEventListener("load", complete, { once: true });
                    existingScript.addEventListener("error", complete, { once: true });
                    return;
                }

                const script = document.createElement("script");
                script.type = "text/javascript";
                script.src = "editor-monaco-language-extensions.js";
                script.async = false;
                script.setAttribute("data-mm-monaco-language-extensions", "true");
                script.onload = complete;
                script.onerror = complete;
                (document.head || document.body || document.documentElement).appendChild(script);
            });

            return te.languageExtensionsReadyPromise;
        },
        ensureThemeDefinitionsReady: function () {
            if (window.mmMonacoThemes &&
                typeof window.mmMonacoThemes.register === "function") {
                return Promise.resolve(window.mmMonacoThemes);
            }

            if (te.themeDefinitionsReadyPromise) {
                return te.themeDefinitionsReadyPromise;
            }

            te.themeDefinitionsReadyPromise = new Promise(function (resolve) {
                const complete = function () {
                    resolve(window.mmMonacoThemes || null);
                };

                const existingScript = document.querySelector("script[data-mm-monaco-themes='true'],script[src$='editor-monaco-themes.js']");
                if (existingScript) {
                    if (window.mmMonacoThemes) {
                        complete();
                        return;
                    }

                    existingScript.addEventListener("load", complete, { once: true });
                    existingScript.addEventListener("error", complete, { once: true });
                    return;
                }

                const script = document.createElement("script");
                script.type = "text/javascript";
                script.src = "editor-monaco-themes.js";
                script.async = false;
                script.setAttribute("data-mm-monaco-themes", "true");
                script.onload = complete;
                script.onerror = complete;
                (document.head || document.body || document.documentElement).appendChild(script);
            });

            return te.themeDefinitionsReadyPromise;
        },

        ensureEditorLayout: function () {
            if (!te.editorElement) {
                return;
            }

            te.editorElement.innerHTML = "<div id='MonacoRoot' class='none'>" +
                "<div id='MonacoPane1' class='monaco-pane'><div id='MonacoSurface1' class='monaco-surface'></div></div>" +
                "<div id='MonacoPane2' class='monaco-pane hidden'><div id='MonacoSurface2' class='monaco-surface'></div></div>" +
                "</div>";

            te.editorRoot = document.getElementById("MonacoRoot");
            te.pane1 = document.getElementById("MonacoPane1");
            te.pane2 = document.getElementById("MonacoPane2");
            te.surface1 = document.getElementById("MonacoSurface1");
            te.surface2 = document.getElementById("MonacoSurface2");
        },
        showRecoveryBar: function () {
            const bar = document.createElement("div");
            bar.className = "mm-recovery-bar";
            bar.setAttribute("role", "region");
            bar.setAttribute("aria-label", "Recovery Mode");
            bar.innerHTML = "<strong style='font-size: 1.15em; color: steelblue'>Recovery Mode</strong>" +
                "<button type='button' id='RecoveryAcceptAll' title='Keep the recovered text and open in the standard editor'>Accept all Changes</button>" +
                "<button type='button' id='RecoveryRevertAll' title='Restore the saved file and open in the standard editor'>Revert all Changes</button>";
            bar.querySelector("#RecoveryAcceptAll").onclick = te.acceptDiffChangesAndOpenEditor;
            bar.querySelector("#RecoveryRevertAll").onclick = te.revertDiffChangesAndOpenEditor;
            te.recoveryBar = bar;
            te.editorElement.classList.add("mm-recovery-mode");
            te.editorElement.insertBefore(bar, te.editorRoot);
        },

        getEditorOptions: function (style) {
            const mapped = te.mapTheme(style && style.theme ? style.theme : "vscodedark");
            monacoRef().editor.setTheme(mapped);

            const fontSize = parseInt((style && style.fontSize) || 16, 10);
            const lineHeightFactor = parseFloat((style && style.lineHeight) || 1.45);
            const lineHeight = Math.max(14, Math.round(fontSize * lineHeightFactor));
            const useSpellAssist = !!editorSettings.enableMonacoSpellcheckAssist;
            const scrollbarSize = 8;

            // Docs for options:
            // https://microsoft.github.io/monaco-editor/typedoc/interfaces/editor_editor_api.editor.IEditorOptions.html
            return {                
                language: "markdown",
                automaticLayout: true,
                contextmenu: te.isEditorSimple,
                hover: {
                    enabled: false,
                    sticky: false
                },
                lineNumbers: style && style.showLineNumbers ? "on" : "off",
                renderWhitespace: style && style.showInvisibles ? "all" : "selection",
                renderControlCharacters: style && style.showInvisibles ? true : false,
                renderLineHighlight: style && style.highlightActiveLine ? "line" : "none",
                wordWrap: style && style.wrapText ? "on" : "off",
                wrappingIndent: "same",
                fontFamily: style && style.font ? style.font : "Consolas",
                fontSize: fontSize,
                lineHeight: lineHeight,
                readOnly: false,
                minimap: { enabled: false },
                padding: { maxEditorCanvasWidth:  te.getCenteredModeMaxWidth(style) },
                scrollBeyondLastLine: true,
                smoothScrolling: true,
                mouseWheelZoom: false,                
                scrollbar: {
                    verticalScrollbarSize: scrollbarSize,
                    horizontalScrollbarSize: scrollbarSize,
                    useShadows: false
                },
                quickSuggestions: useSpellAssist ? { other: true, comments: false, strings: false } : false,
                suggestOnTriggerCharacters: useSpellAssist,
                wordBasedSuggestions: useSpellAssist ? "currentDocument" : "off",
                inlineSuggest: { enabled: false },
                parameterHints: { enabled: useSpellAssist },
                acceptSuggestionOnEnter: useSpellAssist ? "on" : "off",
                snippetSuggestions: "none",
                tabCompletion: "off",
                renderFinalNewline: "on",
                unicodeHighlight: {
                    ambiguousCharacters: false,
                    invisibleCharacters: style.showInvisibles
                },
                guides: {
                    indentation: style.showInvisibles,
                    highlightActiveIndentation: style.showInvisibles
                }
            };
        },
        getDiffEditorOptions: function (style) {
            return Object.assign({}, te.getEditorOptions(style || te.settings), {
                automaticLayout: true,
                contextmenu: false,
                renderSideBySide: te.diffViewMode === "SideBySide",
                enableSplitViewResizing: true,
                originalEditable: false,
                ignoreTrimWhitespace: false
            });
        },
        createSingleEditor: function (text, language, style) {
            const options = te.getEditorOptions(style || te.settings);
            const value = typeof text === "string" ? text : "";
            const lang = language || "markdown";

            te.model = monacoRef().editor.createModel(value, lang);
            te.mainEditor = monacoRef().editor.create(te.surface1 || te.pane1, Object.assign({}, options, { model: te.model }));
            te.editor = te.mainEditor;
            te.editor2 = null;
            te.isDiffMode = false;
            te.diffEditor = null;
            te.diffOriginalModel = null;
            te.splitMode = "None";
            te.applySplitLayout("None");
        },

        createOrResetEditors: function (style) {
            te.disposeEditors();
            te.createSingleEditor("", "markdown", style || te.settings);
        },

        disposeEditors: function () {
            if (te.recoveryBar) {
                te.recoveryBar.remove();
                te.recoveryBar = null;
                te.editorElement.classList.remove("mm-recovery-mode");
            }
            te.isRecoveryMode = false;
            te.recoveryOriginalText = null;
            te.diffSnapshot = null;
            te.diffContextMenuTarget = null;
            te.wheelZoomInFlight = false;
            te.wheelZoomQueuedDirection = 0;            
            while (te.disposerBag.length > 0) {
                const d = te.disposerBag.pop();
                try {
                    if (d && typeof d.dispose === "function") {
                        d.dispose();
                    }
                } catch (_) { }
            }

            if (te.diffEditor) {
                te.diffEditor.dispose();
                te.diffEditor = null;
                te.mainEditor = null;
                te.editor2 = null;
            } else {
                if (te.mainEditor) {
                    te.mainEditor.dispose();
                    te.mainEditor = null;
                }
                if (te.editor2) {
                    te.editor2.dispose();
                    te.editor2 = null;
                }
            }
            if (te.diffOriginalModel) {
                te.diffOriginalModel.dispose();
                te.diffOriginalModel = null;
            }
            if (te.model) {
                te.model.dispose();
                te.model = null;
            }
            te.isDiffMode = false;
            te.diffViewMode = "Inline";
            te.editor = null;
        },

        configureEvents: function () {
            if (!te.mainEditor) {
                return;
            }

            te.attachEditorEvents(te.mainEditor);
            te.attachDropEvents(te.mainEditor);
            if (te.diffEditor) {
                te.attachContextMenuEvents(te.diffEditor.getOriginalEditor());
            }

            window.onresize = te.windowResize;
            window.addEventListener("wheel", te.onWheel, { passive: false, capture: true });
            te.disposerBag.push({
                dispose: function () {
                    window.removeEventListener("wheel", te.onWheel, true);
                }
            });

            const tooltipLinkHandler = function (event) {
                if (!event || !event.target) {
                    return;
                }

                const anchor = event.target.closest ? event.target.closest("a[href]") : null;
                if (!anchor) {
                    return;
                }

                const href = anchor.getAttribute("href") || "";
                if (!href || href.indexOf("mm-spell://suggest") !== 0) {
                    return;
                }

                event.preventDefault();
                event.stopPropagation();
                te.openSpellSuggestionsFromLink(href, anchor);
            };

            document.addEventListener("click", tooltipLinkHandler, true);
            te.disposerBag.push({
                dispose: function () {
                    document.removeEventListener("click", tooltipLinkHandler, true);
                }
            });

            const tooltipDismissHandler = function (event) {
                if (te.isEditorSimple || !event || !event.target) {
                    return;
                }
                // Keep tooltip interactive while pointer is in hover.
                if (event.target.closest && event.target.closest(".monaco-hover")) {
                    return;
                }
                te.dismissHoverTooltip();
            };

            document.addEventListener("click", tooltipDismissHandler, true);
            te.disposerBag.push({
                dispose: function () {
                    document.removeEventListener("click", tooltipDismissHandler, true);
                }
            });
        },

        attachEditorEvents: function (editor) {
            te.disposerBag.push(editor.onDidFocusEditorText(function () {
                te.editor = editor;
                te.onGotFocus();
            }));

            te.disposerBag.push(editor.onDidBlurEditorText(function () {
                te.onBlur();
            }));

            te.disposerBag.push(editor.onDidChangeCursorPosition(function (e) {
                if (!e || !e.position) {
                    return;
                }
                te.mousePos = fromMonacoPos(e.position);
                te.updateDocumentStats();
                te.onCursorOrClickPositionChanged();
            }));

            te.disposerBag.push(editor.onDidChangeModelContent(function (e) {
                te.onEditorContentChanged(e);
            }));

            te.disposerBag.push(editor.onDidScrollChange(
                debounce(function () {
                    te.onScrollChanged(editor);
                }, 80)));

            te.disposerBag.push(editor.onMouseMove(function (e) {
                if (e && e.target && e.target.position) {
                    te.mousePos = fromMonacoPos(e.target.position);
                }
            }));

            te.disposerBag.push(editor.onMouseUp(function () {
                if (te.mm) {
                    te.scrollPreviewRefresh(-1, false, false, true);
                }
                te.updateDocumentStats();
                if (te.mm && !te.isEditorSimple) {
                    te.mm.SetPreviewMode(true);
                }
                te.setCodeScrolled();
                te.onCursorOrClickPositionChanged();
            }));

            te.disposerBag.push(editor.onContextMenu(function (e) {
                if (te.isEditorSimple) {
                    return;
                }
                // Suppress Monaco's built-in context menu; the DOM contextmenu
                // event in attachDropEvents is the sole trigger for the WPF menu.
                if (e && e.event && e.event.browserEvent) {
                    e.event.browserEvent.preventDefault();
                    e.event.browserEvent.stopPropagation();
                }
                if (e && e.target && e.target.position) {
                    te.lastContextMenuPos = e.target.position;
                }
            }));

            te.disposerBag.push(editor.onKeyDown(function (e) {
                te.onEditorKeyDown(editor, e);
            }));

            // Override Monaco's built-in "Trigger Suggest" keybinding (Ctrl+Space) so it
            // doesn't pop up the native suggest widget (showing "No suggestions.") while
            // we're using Ctrl+Space to request an AI ghost-text completion instead.
            editor.addCommand(monacoRef().KeyMod.CtrlCmd | monacoRef().KeyCode.Space, function () {
                if (te.mm && te.mmAsync && !te.isEditorSimple) {
                    te.mmAsync.RequestGhostText();
                }
            });

            // Override Monaco's default Tab keybinding so accepting ghost text doesn't
            // also run its normal indent behavior; falls back to the default "tab" command otherwise.
            editor.addCommand(monacoRef().KeyCode.Tab, function () {
                if (te.ghostTextContent) {
                    te.acceptGhostText();
                } else {
                    editor.trigger("keyboard", "tab", null);
                }
            });
        },

        attachDropEvents: function (editor) {
            const dom = editor.getDomNode();
            if (!dom) {
                return;
            }

            const dragOver = function (event) {
                event.preventDefault();
                event.stopPropagation();
                te.mousePos = fromMonacoPos(editor.getPosition());
            };

            const drop = function (event) {
                event.preventDefault();
                event.stopPropagation();
                te.handleDropEvent(event);
            };

            dom.addEventListener("dragover", dragOver);
            dom.addEventListener("drop", drop);
            te.attachContextMenuEvents(editor);

            te.disposerBag.push({
                dispose: function () {
                    dom.removeEventListener("dragover", dragOver);
                    dom.removeEventListener("drop", drop);
                }
            });
        },
        attachContextMenuEvents: function (editor) {
            const dom = editor.getDomNode();
            if (!dom) {
                return;
            }
            const contextMenu = function (event) {
                if (!te.mmAsync || te.isEditorSimple) {
                    return;
                }

                event.preventDefault();
                event.stopPropagation();

                let position = editor.getPosition();
                const target = editor.getTargetAtClientPoint(event.clientX, event.clientY);
                if (target && target.position) {
                    position = target.position;
                }

                te.lastContextMenuPos = position;
                te.captureDiffContextMenuTarget(editor, target);
                te.setCodeScrolled();
                te.showSuggestions({
                    target: { position: position },
                    clientX: event.clientX,
                    clientY: event.clientY
                });
            };

            dom.addEventListener("contextmenu", contextMenu);

            te.disposerBag.push({
                dispose: function () {
                    dom.removeEventListener("contextmenu", contextMenu);
                }
            });
        },

        onEditorKeyDown: function (editor, e) {
            if (!e || !e.browserEvent || te.isEditorSimple) {
                return;
            }

            const evt = e.browserEvent;
            const key = (evt.key || "").toLowerCase();
            const ctrlOrMeta = !!(evt.ctrlKey || evt.metaKey);

            if (key === "tab") {
                // Handled via editor.addCommand override registered in attachEditorEvents,
                // which takes precedence over Monaco's default "tab" keybinding.
                return;
            }

            if (key === "escape" && te.ghostTextContent) {
                evt.preventDefault();
                evt.stopPropagation();
                te.clearGhostText();
                return;
            }

            if (evt.ctrlKey && key === " ") {
                // Handled via editor.addCommand override registered in attachEditorEvents,
                // which takes precedence over Monaco's default "Trigger Suggest" keybinding.
                return;
            }

            if (ctrlOrMeta &&
                (key === "+" || key === "=" || key === "add" || key === "-" || key === "_" || key === "subtract")) {
                evt.preventDefault();
                evt.stopPropagation();
                if (key === "-" || key === "_" || key === "subtract") {
                    te.requestZoomStep(-1);
                } else {
                    te.requestZoomStep(1);
                }
                return;
            }

            const binding = te.lookupHostBinding(evt);
            if (binding) {
                evt.preventDefault();
                evt.stopPropagation();
                te.executeHostBinding(binding);
            }

            if (key === "arrowup" || key === "arrowdown") {
                te.scrollPreviewRefresh(-1, false, false, false);
            } else if (key === "arrowleft" || key === "arrowright") {
                te.updateDocumentStats();
            } else if (key === "control") {
                te.refreshPreview();
                te.updateDocumentStats();
                te.spellcheckDocument(true);
            } else {
                te.updateDocument();
            }
            te.setCodeScrolled();
        },

        onEditorContentChanged: function () {
            if (te.ghostTextContent) {
                te.clearGhostText();
            }

            if (te._suppressUndoTracking) {
                // Programmatic reset/load operation that intentionally bypasses undo history.
            } else if (te._isUndoRedoOperation) {
                te._isUndoRedoOperation = false;
            } else {
                te._changeCount++;
                te._redoCount = 0;
            }

            te.updateDocument();

            if (te.getLineCount() > 20000 && te.previewRefreshTimeout !== te.previewRefreshTimeoutSlow) {
                te.previewRefreshTimeout = te.previewRefreshTimeoutSlow;
            }

            if (te.spellcheckEnabled) {
                te.spellcheckContentModified = true;
                te.scheduleSpellcheck(false);
            }
        },

        onScrollChanged: function (editor) {
            if (te.isCodeScrolled(te.previewScrollTimeout)) {
                return;
            }

            const info = te.getVisibleRows(editor);
            if (!info) {
                return;
            }

            let firstRow = info.firstRow;
            if (firstRow > 2) {
                firstRow += 3;
            } else {
                firstRow = 0;
            }

            te.scrollPreviewRefresh(firstRow, false, false, false, 0.1);

            if (te.spellcheckEnabled) {
                // Re-evaluate misspellings for the new viewport after scroll settles.
                te.spellcheckContentModified = true;
                te.scheduleSpellcheck(false);
            }
        },

        handleDropEvent: function (event) {
            if (te.isEditorSimple || !te.mmAsync) {
                return;
            }

            const dataTransfer = event.dataTransfer;
            if (!dataTransfer) {
                return;
            }

            const text = dataTransfer.getData("text");
            if (text) {
                const dragMode = dataTransfer.dropEffect || "none";
                te.mmAsync.EmbedDroppedFileAsImage(text, dragMode === "copy");
                te.setselection("");
                return;
            }

            if (dataTransfer.files && dataTransfer.files.length > 0) {
                const file = dataTransfer.files[0];
                if (!file) {
                    return;
                }

                if (file.path) {
                    te.mmAsync.EmbedDroppedFileAsImage(file.path, false);
                    te.setselection("");
                    return;
                }

                const reader = new FileReader();
                reader.onload = function (e) {
                    const obj = {
                        name: file.name,
                        media: file.type,
                        size: file.size,
                        data: e && e.target ? e.target.result : null
                    };
                    te.mmAsync.EmbedDroppedFileAsImage("droppedfile:" + JSON.stringify(obj), true);
                    te.setselection("");
                };
                reader.readAsDataURL(file);
            }
        },

        setupHostKeyBindings: function () {
            te.hostBindings = [];
            te.hostBindingLookup = {};

            if (te.isEditorSimple || !te.mm || !te.mm.GetKeyBindingsJson) {
                return;
            }

            let keyBindingsJson = null;
            try {
                keyBindingsJson = te.mm.GetKeyBindingsJson();
            } catch (_) {
                return;
            }

            if (!keyBindingsJson) {
                return;
            }

            let keyBindings = [];
            try {
                keyBindings = JSON.parse(keyBindingsJson);
            } catch (_) {
                return;
            }

            for (let i = 0; i < keyBindings.length; i++) {
                const kb = keyBindings[i];
                if (!kb || !kb.CommandName || !kb.Key) {
                    continue;
                }

                const commandName = kb.CommandName[0].toLowerCase() + kb.CommandName.substr(1);
                const normalized = normalizeShortcut(kb.Key);
                if (!normalized) {
                    continue;
                }

                const binding = {
                    id: kb.Id || kb.CommandName,
                    commandName: commandName,
                    hint: kb.CommandParameter,
                    normalized: normalized
                };

                te.hostBindings.push(binding);
                te.hostBindingLookup[normalized] = binding;
            }
        },

        lookupHostBinding: function (evt) {
            const normalized = normalizeEventShortcut(evt);
            if (!normalized) {
                return null;
            }

            return te.hostBindingLookup[normalized] || null;
        },

        executeHostBinding: function (binding) {
            if (!binding || !binding.commandName) {
                return;
            }

            const cmd = binding.commandName;
            const hint = binding.hint;

            switch (cmd) {
                case "editorCommand":
                    te.keyboardCommand("EditorCommand", hint);
                    break;
                case "insertCodeBlock":
                    te.keyboardCommand("InsertCodeBlock");
                    break;
                case "gotoLine":
                    te.keyboardCommand("GotoLine");
                    break;
                case "saveDocument":
                    te.keyboardCommand("SaveDocument");
                    break;
                case "newDocument":
                    te.keyboardCommand("NewDocument");
                    break;
                case "openDocument":
                    te.keyboardCommand("OpenDocument");
                    break;
                case "reloadEditor":
                    te.keyboardCommand("ReloadEditor");
                    break;
                case "showHelp":
                    te.keyboardCommand("ShowHelp");
                    break;
                case "find":
                    te.getEditor().getAction("actions.find").run();
                    break;
                case "findNext":
                    te.getEditor().getAction("editor.action.nextMatchFindAction").run();
                    break;
                case "findPrevious":
                    te.getEditor().getAction("editor.action.previousMatchFindAction").run();
                    break;
                case "deleteCurrentLine":
                    te.deleteCurrentLine();
                    break;
                case "nextTab":
                    te.keyboardCommand("NextTab");
                    break;
                case "previousTab":
                    te.keyboardCommand("PreviousTab");
                    break;
                case "zoomEditorDown":
                    te.keyboardCommand("ZoomEditorDown");
                    break;
                case "zoomEditorUp":
                    te.keyboardCommand("ZoomEditorUp");
                    break;
                case "removeMarkdownFormatting":
                    te.keyboardCommand("RemoveMarkdownFormatting");
                    break;
                case "paste":
                case "paste2":
                    if (te.mmAsync) {
                        te.mmAsync.PasteOperation();
                    }
                    break;
                case "copy":
                    if (te.mmAsync) {
                        te.mmAsync.CopyOperation();
                    }
                    break;
                case "cut":
                    if (te.mmAsync) {
                        te.mmAsync.CutOperation();
                    }
                    break;
                case "nextSpellCheckError":
                    te.spellcheckNext();
                    break;
                case "previousSpellCheckError":
                    te.spellcheckPrevious();
                    break;
                default:
                    break;
            }
        },

        updateDocument: debounce(function (force) {
            if (!te.mm || !te.mmAsync) {
                return;
            }

            te.mmAsync.IsDirty(false, te.getvalue())
                .then(function (dirty) {
                    te.isDirty = !!dirty;
                    if (!te.isEditorSimple && (force || te.isDirty)) {
                        te.refreshPreview();
                        te.updateDocumentStats();
                    }
                })
                .catch(function () { });
        }, defaultPreviewRefreshTimeout),

        refreshPreview: debounce(function () {
            if (!te.mm || te.isEditorSimple || te.noRefreshPreview) {
                return;
            }

            const ratio = te.getEditorRatio();
            const noPreviewScrolling = te.settings.previewSyncMode === 3 || te.settings.previewSyncMode === 0;
            te.mm.PreviewMarkdownCallback(true, -1, noPreviewScrolling || ratio === 0);
        }, previewRefreshDelay),

        scrollPreviewRefresh: debounce(function (editorLine, noScrollTimeout, noScrollTopAdjustment, force, editorRatio) {
            if (!te.mmAsync || te.isEditorSimple || te.noRefreshPreview) {
                return;
            }

            if (!force &&
                te.settings.previewSyncMode !== 2 &&
                te.settings.previewSyncMode !== 4) {
                return;
            }

            if (typeof editorLine !== "number" || editorLine < 0) {
                editorLine = te.getLineNumber();
            }

            if (typeof editorRatio !== "number") {
                editorRatio = te.getEditorRatio();
            }

            if (!noScrollTimeout) {
                te.setCodeScrolled();
            }

            te.mmAsync.ScrollPreviewToEditorLineCallback(editorLine, true, !!noScrollTimeout, !!noScrollTopAdjustment, editorRatio || 0.1);
        }, previewRefreshDelay),

        setShowLineNumbers: function (showLineNumbers) {
            te.updateAllEditors(function (editor) {
                editor.updateOptions({ lineNumbers: showLineNumbers ? "on" : "off" });
            });
        },
        setShowInvisibles: function (showInvisibles) {
            te.updateAllEditors(function (editor) {
                editor.updateOptions({ 
                    renderWhitespace: showInvisibles ? "all" : "selection",
                    renderControlCharacters: showInvisibles ? true : false,
                    renderFinalNewline: showInvisibles ? "on" : "off",
                    unicodeHighlight: {
                        invisibleCharacters: style.showInvisibles
                    },
                    guides: {
                        indentation: style.showInvisibles,
                        highlightActiveIndentation: style.showInvisibles
                    }                    
                });
            });
        },
        setWordWrap: function (enable) {
            te.updateAllEditors(function (editor) {
                editor.updateOptions({ wordWrap: enable ? "on" : "off" });
            });
        },
        setReadOnly: function (status) {
            te.updateAllEditors(function (editor) {
                editor.updateOptions({ readOnly: !!status });
            });
        },
        setRightToLeft: function () {
            // Monaco has no direct RTL toggle equivalent for editor content.
        },
        setfont: function (size, fontFace) {
            te.updateAllEditors(function (editor) {
                const opts = {};
                if (size) {
                    opts.fontSize = parseInt(size, 10);
                }
                if (fontFace) {
                    opts.fontFamily = fontFace;
                }
                editor.updateOptions(opts);
            });
        },
        getfontsize: function () {
            const editor = te.getEditor();
            if (!editor) {
                return 0;
            }
            const opts = editor.getOptions();
            const fontSize = opts.get(monacoRef().editor.EditorOption.fontSize);
            return fontSize || 0;
        },
        getscrolltop: function () {
            const editor = te.getEditor();
            return editor ? editor.getScrollTop() : 0;
        },
        setscrolltop: function (scrollTop) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            setTimeout(function () {
                editor.setScrollTop(scrollTop || 0);
            }, 25);
        },
        getvalue: function () {
            return te.model ? te.model.getValue() : "";
        },
        setvalue: function (text, pos, keepUndo) {
            te.runWhenReady(function () {
                const model = te.model;
                if (!model) {
                    return;
                }

                if (typeof text !== "string") {
                    text = text == null ? "" : String(text);
                }

                let offset = -1;
                if (pos === -2) {
                    offset = te.getCharacterOffset();
                }

                if (keepUndo) {
                    model.pushEditOperations([], [{
                        range: model.getFullModelRange(),
                        text: text
                    }], function () { return null; });
                } else {
                    // Full document reset (file load/reload): clear undo history.
                    te._suppressUndoTracking = true;
                    model.setValue(text);
                    te._changeCount = 0;
                    te._redoCount = 0;
                    te._isUndoRedoOperation = false;
                    setTimeout(function () {
                        te._suppressUndoTracking = false;
                    }, 0);
                }

                if (offset >= 0) {
                    te.setCharacterOffset(offset);
                } else {
                    const line = typeof pos === "number" && pos > 0 ? pos : 1;
                    te.gotoLine(line, true, false, 1);
                }
            });
        },
        showGhostText: function (text) {
            te.runWhenReady(function () {
                if (!text) {
                    te.clearGhostText();
                    return;
                }

                const editor = te.getEditor();
                if (!editor) {
                    return;
                }
                const pos = editor.getPosition();

                te.clearGhostText();
                te.ghostTextContent = text;
                te.ghostTextPosition = pos;

                // Strip the leading line break used to place the suggestion on the next line -
                // the view zone below already reserves that line for us.
                const displayText = text.startsWith("\n") ? text.substring(1) : text;

                const node = document.createElement("div");
                node.className = "ghost-text-overlay";
                node.textContent = displayText;

                const layoutInfo = editor.getLayoutInfo();
                const contentWidth = Math.max(200, layoutInfo.contentWidth - 12);
                node.style.width = contentWidth + "px";
                node.style.marginLeft = layoutInfo.contentLeft + "px";

                // Measure the wrapped height inside the editor (to inherit font metrics)
                // so the reserved view zone is tall enough to avoid clipping/overlaying content.
                const editorDom = editor.getDomNode();
                node.style.visibility = "hidden";
                editorDom.appendChild(node);
                const measuredHeight = node.offsetHeight;
                editorDom.removeChild(node);
                node.style.visibility = "";

                const lineHeight = editor.getOption(monacoRef().editor.EditorOption.lineHeight) || 20;
                const heightInLines = Math.max(1, Math.ceil(measuredHeight / lineHeight));

                editor.changeViewZones(function (accessor) {
                    te.ghostZoneId = accessor.addZone({
                        afterLineNumber: pos.lineNumber,
                        heightInLines: heightInLines,
                        domNode: node
                    });
                });
                te.ghostZoneEditor = editor;
            });
        },
        acceptGhostText: function () {
            if (!te.ghostTextContent) {
                return;
            }

            const insertText = te.ghostTextContent.startsWith("\n")
                ? te.ghostTextContent.substring(1)
                : te.ghostTextContent;

            te.setselection(insertText);
            te.clearGhostText();
        },
        clearGhostText: function () {
            const editor = te.ghostZoneEditor || te.getEditor();
            if (editor && te.ghostZoneId != null) {
                editor.changeViewZones(function (accessor) {
                    accessor.removeZone(te.ghostZoneId);
                });
            }

            te.ghostZoneId = null;
            te.ghostZoneEditor = null;
            te.ghostWidget = null;
            te.ghostTextContent = "";
            te.ghostTextPosition = null;
        },

        replaceContent: function (text) {
            te.runWhenReady(function () {
                const model = te.model;
                if (!model) {
                    return;
                }
                model.pushEditOperations([], [{
                    range: model.getFullModelRange(),
                    text: text || ""
                }], function () { return null; });
            });
        },
        refresh: function () {
            te.updateAllEditors(function (editor) {
                editor.layout();
            });
            if (te.diffEditor) {
                te.diffEditor.layout();
            }
        },
        keyboardCommand: function (key, action) {
            if (te.mmAsync) {
                te.mmAsync.KeyboardCommand(key, action);
            }
        },
        requestZoomStep: function (direction) {
            if (!direction) {
                return;
            }

            const normalizedDirection = direction < 0 ? -1 : 1;
            if (!te.mmAsync) {
                return;
            }

            if (te.wheelZoomInFlight) {
                te.wheelZoomQueuedDirection = normalizedDirection;
                return;
            }

            te.wheelZoomInFlight = true;
            te.wheelZoomQueuedDirection = 0;
            const command = normalizedDirection < 0 ? "ZoomEditorDown" : "ZoomEditorUp";

            Promise.resolve(te.mmAsync.KeyboardCommand(command))
                .catch(function () { })
                .finally(function () {
                    te.wheelZoomInFlight = false;
                    if (!te.wheelZoomQueuedDirection) {
                        return;
                    }
                    const queuedDirection = te.wheelZoomQueuedDirection;
                    te.wheelZoomQueuedDirection = 0;
                    te.requestZoomStep(queuedDirection);
                });
        },
        editorSelectionOperation: function (action, text) {
            if (te.mmAsync) {
                te.mmAsync.EditorSelectionOperation(action, text);
            }
        },
        gotoLine: function (line, noRefresh, noSelection, column) {
            te.runWhenReady(function () {
                const editor = te.getEditor();
                const model = te.model;
                if (!editor || !model) {
                    return;
                }

                if (typeof line !== "number") {
                    return;
                }

                if (line === -1) {
                    line = te.getLineNumber() + 1;
                }

                const maxLine = model.getLineCount();
                line = Math.max(1, Math.min(maxLine, line));
                const col = Math.max(1, (parseInt(column || 1, 10)));

                editor.revealLineInCenter(line);
                editor.setPosition({ lineNumber: line, column: col });

                if (!noSelection) {
                    editor.setSelection({
                        startLineNumber: line,
                        startColumn: col,
                        endLineNumber: line,
                        endColumn: col
                    });
                }

                if (noRefresh) {
                    te.suspendPreviewRefresh();
                } else {
                    setTimeout(function () {
                        te.refreshPreview();
                        te.updateDocumentStats();
                    }, 10);
                }
            });
        },
        gotoSyncedLine: function (line) {
            te.runWhenReady(function () {
                const editor = te.getEditor();
                const model = te.model;
                if (!editor || !model) {
                    return;
                }

                if (typeof line !== "number") {
                    return;
                }
                if (line === -1) {
                    line = te.getLineNumber() + 1;
                }

                const maxLine = model.getLineCount();
                line = Math.max(1, Math.min(maxLine, line));
                te.suspendPreviewRefresh();

                editor.revealLineNearTop(line);
                editor.setPosition({ lineNumber: line, column: 1 });
                editor.setSelection({
                    startLineNumber: line,
                    startColumn: 1,
                    endLineNumber: line,
                    endColumn: 1
                });
            });
        },
        gotoBottom: function (noRefresh, noSelection) {
            const line = Math.max(1, te.getLineCount());
            te.gotoLine(line, noRefresh, noSelection, 1);
        },
        getLineAndRatio: function () {
            return {
                line: te.getLineNumber(),
                ratio: te.getEditorRatio()
            };
        },
        setselection: function (text) {
            te.runWhenReady(function () {
                const editor = te.getEditor();
                if (!editor) {
                    return;
                }
                const selection = editor.getSelection();
                editor.executeEdits("mm-setselection", [{
                    range: selection,
                    text: text || "",
                    forceMoveMarkers: true
                }]);
                editor.focus();
            });
        },
        clearSelection: function () {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            const pos = editor.getPosition();
            editor.setSelection({
                startLineNumber: pos.lineNumber,
                startColumn: pos.column,
                endLineNumber: pos.lineNumber,
                endColumn: pos.column
            });
        },
        setSelectionRange: function (startRowOrRange, startColumn, endRow, endColumn) {
            te.runWhenReady(function () {
                const editor = te.getEditor();
                if (!editor) {
                    return;
                }

                const range = parseRangeArgs(startRowOrRange, startColumn, endRow, endColumn);
                editor.setSelection(range);
            });
        },
        replaceSelectionRange: function (text, rangeOrStartRow, startColumn, endRow, endColumn) {
            te.runWhenReady(function () {
                const editor = te.getEditor();
                if (!editor) {
                    return;
                }
                const range = parseRangeArgs(rangeOrStartRow, startColumn, endRow, endColumn);
                editor.executeEdits("mm-replaceSelectionRange", [{
                    range: range,
                    text: text || "",
                    forceMoveMarkers: true
                }]);
                editor.setSelection(range);
            });
        },
        selectLine: function (lineNo) {
            const editor = te.getEditor();
            const model = te.model;
            if (!editor || !model) {
                return;
            }

            let line = lineNo;
            if (typeof line !== "number" || line < 0) {
                const pos = editor.getPosition();
                line = (pos && pos.lineNumber ? pos.lineNumber : 1) - 1;
            }
            line = Math.max(0, Math.min(model.getLineCount() - 1, line));
            const text = model.getLineContent(line + 1);

            editor.setSelection({
                startLineNumber: line + 1,
                startColumn: 1,
                endLineNumber: line + 1,
                endColumn: text.length + 1
            });
        },
        getselection: function () {
            const editor = te.getEditor();
            if (!editor || !te.model) {
                return "";
            }
            const selection = editor.getSelection();
            if (!selection) {
                return "";
            }
            return te.model.getValueInRange(selection);
        },
        getselectionrange: function () {
            const editor = te.getEditor();
            if (!editor) {
                return null;
            }
            return fromMonacoRange(editor.getSelection());
        },
        getCursorPosition: function () {
            const editor = te.getEditor();
            if (!editor) {
                return { row: 0, column: 0, dragMode: "none" };
            }
            const pos = editor.getPosition();
            const converted = fromMonacoPos(pos);
            converted.dragMode = "none";
            return converted;
        },
        getCharacterOffset: function (pos) {
            const model = te.model;
            if (!model) {
                return -1;
            }
            let position = null;
            if (pos && typeof pos.row === "number" && typeof pos.column === "number") {
                position = toMonacoPos(pos.row, pos.column);
            } else {
                const editor = te.getEditor();
                position = editor ? editor.getPosition() : null;
            }
            if (!position) {
                return -1;
            }
            return model.getOffsetAt(position);
        },
        setCharacterOffset: function (offset) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return;
            }

            const max = model.getValueLength();
            const safeOffset = Math.max(0, Math.min(max, parseInt(offset || 0, 10)));
            const position = model.getPositionAt(safeOffset);
            editor.setPosition(position);
            editor.revealPositionInCenterIfOutsideViewport(position);
        },
        setselposition: function (index, count) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return;
            }

            const start = model.getPositionAt(Math.max(0, index || 0));
            const end = model.getPositionAt(Math.max(0, (index || 0) + (count || 0)));
            editor.setSelection({
                startLineNumber: start.lineNumber,
                startColumn: start.column,
                endLineNumber: end.lineNumber,
                endColumn: end.column
            });
            editor.revealPositionInCenter(start);
        },
        setselpositionfrommouse: function (pos) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }

            const target = pos && typeof pos.row === "number" && typeof pos.column === "number"
                ? toMonacoPos(pos.row, pos.column)
                : toMonacoPos(te.mousePos.row, te.mousePos.column);

            editor.setPosition(target);
            editor.setSelection({
                startLineNumber: target.lineNumber,
                startColumn: target.column,
                endLineNumber: target.lineNumber,
                endColumn: target.column
            });
        },
        setCursorPosition: function (row, column) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            const pos = typeof row === "object"
                ? toMonacoPos(row.row, row.column)
                : toMonacoPos(row, column);
            editor.setPosition(pos);
            editor.revealPositionInCenterIfOutsideViewport(pos);
        },
        deleteCurrentLine: function () {
            const editor = te.getEditor();
            const model = te.model;
            if (!editor || !model) {
                return;
            }

            const selection = editor.getSelection();
            if (!selection.isEmpty()) {
                editor.executeEdits("mm-deleteSelection", [{ range: selection, text: "" }]);
                return;
            }

            const line = selection.startLineNumber;
            const lineText = model.getLineContent(line);
            const nextLine = Math.min(model.getLineCount(), line + 1);
            const range = {
                startLineNumber: line,
                startColumn: 1,
                endLineNumber: nextLine,
                endColumn: nextLine === line ? lineText.length + 1 : 1
            };
            editor.executeEdits("mm-deleteLine", [{ range: range, text: "" }]);
        },
        moveCursorLeft: function (count) {
            te.moveCursorOffset(-Math.max(1, count || 1));
        },
        moveCursorRight: function (count) {
            te.moveCursorOffset(Math.max(1, count || 1));
        },
        moveCursorUp: function (count) {
            te.moveCursorLineOffset(-(Math.max(1, count || 1)));
        },
        moveCursorDown: function (count) {
            te.moveCursorLineOffset(Math.max(1, count || 1));
        },
        getLineNumber: function () {
            const editor = te.getEditor();
            if (!editor) {
                return -1;
            }
            const pos = editor.getPosition();
            if (!pos || typeof pos.lineNumber !== "number") {
                return -1;
            }
            return pos.lineNumber - 1;
        },
        getCurrentLine: function () {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return "";
            }
            const pos = editor.getPosition();
            if (!pos || typeof pos.lineNumber !== "number") {
                return "";
            }
            const lineNumber = Math.max(1, Math.min(model.getLineCount(), pos.lineNumber));
            return model.getLineContent(lineNumber);
        },
        getLine: function (row) {
            const model = te.model;
            if (!model) {
                return "";
            }
            const line = Math.max(1, Math.min(model.getLineCount(), (parseInt(row || 0, 10) + 1)));
            return model.getLineContent(line);
        },
        findText: function (search) {
            if (!search || !te.model) {
                return;
            }
            const editor = te.getEditor();
            // Monaco searches multiline text using LF, regardless of the model's EOL.
            search = search.replace(/\r\n|\r/g, "\n");
            const matches = te.model.findMatches(search, true, false, false, null, true);
            if (!matches || matches.length === 0) {
                return;
            }

            const curOffset = te.getCharacterOffset();
            let match = matches[0];
            for (let i = 0; i < matches.length; i++) {
                if (te.model.getOffsetAt(matches[i].range.getStartPosition()) >= curOffset) {
                    match = matches[i];
                    break;
                }
            }
            editor.setSelection(match.range);
            editor.revealRangeInCenter(match.range);
        },
        findAndReplaceText: function (search, replace) {
            if (!search || !te.model) {
                return;
            }
            // Monaco searches multiline text using LF, regardless of the model's EOL.
            search = search.replace(/\r\n|\r/g, "\n");
            const matches = te.model.findMatches(search, true, false, false, null, true);
            if (!matches || matches.length === 0) {
                return;
            }
            te.getEditor().executeEdits("mm-findReplace", [{ range: matches[0].range, text: replace || "" }]);
        },
        findAndReplaceTextInCurrentLine: function (search, replace) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor || !search) {
                return;
            }
            const pos = editor.getPosition();
            const line = pos && pos.lineNumber ? pos.lineNumber : 1;
            const text = model.getLineContent(line);
            const idx = text.indexOf(search);
            if (idx < 0) {
                return;
            }
            const range = {
                startLineNumber: line,
                startColumn: idx + 1,
                endLineNumber: line,
                endColumn: idx + search.length + 1
            };
            editor.executeEdits("mm-findReplaceLine", [{ range: range, text: replace || "" }]);
        },
        findAndSelectTextInCurrentLine: function (search) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor || !search) {
                return;
            }
            const pos = editor.getPosition();
            const line = pos && pos.lineNumber ? pos.lineNumber : 1;
            const text = model.getLineContent(line);
            const idx = text.indexOf(search);
            if (idx < 0) {
                return;
            }
            editor.setSelection({
                startLineNumber: line,
                startColumn: idx + 1,
                endLineNumber: line,
                endColumn: idx + search.length + 1
            });
        },
        openSearch: function (searchText) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            editor.getAction("actions.find").run();
            if (searchText) {
                te.findText(searchText);
            }
        },
        openSearchAndReplace: function (searchText, replaceText) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            editor.getAction("editor.action.startFindReplaceAction").run();
            if (searchText) {
                te.findAndReplaceText(searchText, replaceText || "");
            }
        },
        fireTabKey: function () {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            editor.trigger("keyboard", "type", { text: "\t" });
        },
        fireKey: function (key) {
            if (key === "Tab") {
                te.fireTabKey();
            }
        },
        status: function (msg) {
            status(msg);
        },
        curStats: { wordCount: 0, lines: 0, characters: 0 },
        getDocumentStats: function () {
            const text = te.getvalue();
            const pos = te.getCursorPosition();

            const frontMatterExp = /^---[ \t]*$[^]+?^(---|...)[ \t]*$/m;
            const match = frontMatterExp.exec(text);
            let statsText = text;
            if (match && match.index === 0) {
                statsText = statsText.substr(match[0].length);
            }

            const wordCount = statsText.trim().length === 0
                ? 0
                : statsText.replace(/\s+/g, " ").trim().split(" ").length;
            const lines = statsText.length === 0 ? 0 : statsText.split("\n").length;
            const chars = statsText.length;

            te.curStats = {
                wordCount: wordCount,
                lines: lines,
                characters: chars,
                row: pos.row + 1,
                column: pos.column + 1
            };
            return te.curStats;
        },
        updateDocumentStats: function () {
            if (te.isEditorSimple || !te.mm) {
                return;
            }
            setTimeout(function () {
                const stats = te.getDocumentStats();
                te.mm.UpdateDocumentStats(JSON.stringify(stats));
            }, 50);
        },
        enablespellchecking: function (disable, dictionary) {
            if (dictionary) {
                te.spellcheckDictionary = dictionary;
                editorSettings.dictionary = dictionary;
            }
            te.spellcheckEnabled = !disable;
            editorSettings.enableSpellChecking = te.spellcheckEnabled;
            te.spellcheckUseMonacoAssist = !!editorSettings.enableMonacoSpellcheckAssist;
            te.spellcheckContentModified = true;
            if (!te.spellcheckEnabled) {
                if (te.spellcheckTimer) {
                    clearTimeout(te.spellcheckTimer);
                    te.spellcheckTimer = null;
                }
                te.clearSpellcheckMarkers();
            } else {
                te.scheduleSpellcheck(true);
            }
        },
        isspellcheckingenabled: function () {
            return te.spellcheckEnabled;
        },
        applySpellAssistOptions: function () {
            const useSpellAssist = !!te.spellcheckUseMonacoAssist;
            te.updateAllEditors(function (editor) {
                editor.updateOptions({
                    quickSuggestions: useSpellAssist ? { other: true, comments: false, strings: false } : false,
                    suggestOnTriggerCharacters: useSpellAssist,
                    wordBasedSuggestions: useSpellAssist ? "currentDocument" : "off",
                    inlineSuggest: { enabled: useSpellAssist },
                    parameterHints: { enabled: useSpellAssist },
                    acceptSuggestionOnEnter: useSpellAssist ? "on" : "off",
                    snippetSuggestions: "none",
                    tabCompletion: "off"
                });
            });
        },
        setspellcheckassistmode: function (enabled) {
            te.spellcheckUseMonacoAssist = !!enabled;
            editorSettings.enableMonacoSpellcheckAssist = te.spellcheckUseMonacoAssist;
            te.applySpellAssistOptions();
            te.spellcheckContentModified = true;
            te.scheduleSpellcheck(true);
        },
        onCursorOrClickPositionChanged: function () {
            if (!te.spellcheckEnabled || te.isEditorSimple) {
                return;
            }
            // Re-run spellcheck when caret position changes so the previously
            // skipped active word is re-evaluated once caret moves away.
            te.spellcheckContentModified = true;
            te.scheduleSpellcheck(false);
        },
        scheduleSpellcheck: function (force) {
            if (!te.spellcheckEnabled || te.isEditorSimple) {
                return;
            }

            const timeout = force ? 0 : 220;
            if (te.spellcheckTimer) {
                clearTimeout(te.spellcheckTimer);
            }
            te.spellcheckTimer = setTimeout(function () {
                te.spellcheckTimer = null;
                te.spellcheckDocument(!!force);
            }, timeout);
        },
        spellcheckDocument: function (force) {
            te.runWhenReady(function () {
                if (!te.spellcheckEnabled || te.isEditorSimple || !te.mm) {
                    te.clearSpellcheckMarkers();
                    return;
                }

                if (te.spellcheckRunning && !force) {
                    return;
                }
                if (!force && !te.spellcheckContentModified) {
                    return;
                }

                te.spellcheckRunning = true;
                try {
                    const words = te.collectMisspellings();
                    te.spellcheckWords = words;
                    te.applySpellcheckMarkers(words);
                    te.spellcheckContentModified = false;

                    const errorLimit = (editorSettings && typeof editorSettings.spellcheckerErrorLimit === "number")
                        ? editorSettings.spellcheckerErrorLimit
                        : 150;
                    // Keep legacy underlines visible on forced refreshes (initial load/manual runs).
                    // Only auto-disable on background cycles when the error count remains excessive.
                    if (!force && errorLimit > 0 && words.length > errorLimit) {
                        if (te.mm && typeof te.mm.SetSpellChecking === "function") {
                            te.mm.SetSpellChecking(true);
                        }
                        te.enablespellchecking(true);
                        if (te.mm && typeof te.mm.ShowStatusError === "function") {
                            te.mm.ShowStatusError("Spell checking has been turned off as there are too many spelling errors. Please check your language.");
                        }
                    }
                } finally {
                    te.spellcheckRunning = false;
                }
            });
        },
        spellcheckNext: function () {
            te.moveToSpellcheckError(1);
        },
        spellcheckPrevious: function () {
            te.moveToSpellcheckError(-1);
        },
        checkSpelling: function (word) {
            if (!word || !te.mm || !te.spellcheckEnabled || te.isEditorSimple) {
                return true;
            }
            const dictionary = te.spellcheckDictionary || editorSettings.dictionary || null;
            try {
                return !!te.mm.CheckSpelling(word, dictionary, false);
            } catch (_) {
                try {
                    // Fallback to host-configured default dictionary.
                    return !!te.mm.CheckSpelling(word, null, false);
                } catch (_) {
                    return false;
                }
            }
        },
        showSuggestions: function (e) {
            if (!te.mmAsync || te.isEditorSimple) {
                return;
            }

            // Debounce: ignore a second call within 300ms of the first
            const now = Date.now();
            if (te._lastContextMenuTime && (now - te._lastContextMenuTime) < 300) {
                return;
            }
            te._lastContextMenuTime = now;

            let position = null;
            if (e && e.target && e.target.position) {
                position = e.target.position;
            } else if (te.lastContextMenuPos) {
                position = te.lastContextMenuPos;
            } else {
                const editor = te.getEditor();
                position = editor ? editor.getPosition() : null;
            }

            let mousePoint = null;
            if (e && typeof e.clientX === "number" && typeof e.clientY === "number") {
                mousePoint = { x: e.clientX, y: e.clientY };
            } else if (e && e.event && e.event.browserEvent &&
                typeof e.event.browserEvent.clientX === "number" &&
                typeof e.event.browserEvent.clientY === "number") {
                mousePoint = { x: e.event.browserEvent.clientX, y: e.event.browserEvent.clientY };
            }

            if (!position) {
                if (!mousePoint) {
                    const editor = te.getEditor();
                    if (editor) {
                        const p = editor.getPosition();
                        mousePoint = te.positionToScreenPoint(p);
                    }
                }
                if (mousePoint) {
                    te.mmAsync.OpenEditorContextMenu(mousePoint.x, mousePoint.y);
                }
                return;
            }

            const row = position.lineNumber - 1;
            const col = position.column - 1;
            let matched = null;
            for (let i = 0; i < te.spellcheckWords.length; i++) {
                const item = te.spellcheckWords[i];
                if (row < item.startRow || row > item.endRow) {
                    continue;
                }
                if (row === item.startRow && col < item.startColumn) {
                    continue;
                }
                // endColumn is exclusive; a click at endColumn is outside the misspelled word
                if (row === item.endRow && col >= item.endColumn) {
                    continue;
                }
                matched = item;
                break;
            }

            if (matched) {
                const range = {
                    start: { row: matched.startRow, column: matched.startColumn },
                    end: { row: matched.endRow, column: matched.endColumn },
                    misspelled: matched.word
                };
                te.requestSpellSuggestions(matched.word, JSON.stringify(range), null);
            } else {
                if (!mousePoint) {
                    mousePoint = te.positionToScreenPoint(position);
                }
                te.mmAsync.OpenEditorContextMenu(mousePoint.x, mousePoint.y);
            }
        },
        openSpellSuggestionsFromLink: function (href, sourceAnchor) {
            if (!href || !te.mmAsync || te.isEditorSimple) {
                return;
            }

            let url;
            try {
                url = new URL(href);
            } catch (_) {
                return;
            }
            const row = parseInt(url.searchParams.get("row"), 10);
            const startColumn = parseInt(url.searchParams.get("startColumn"), 10);
            const endColumn = parseInt(url.searchParams.get("endColumn"), 10);
            const word = url.searchParams.get("word") || "";

            if (!word || !Number.isFinite(row) || !Number.isFinite(startColumn) || !Number.isFinite(endColumn)) {
                return;
            }

            const range = {
                start: { row: row, column: startColumn },
                end: { row: row, column: endColumn },
                misspelled: word
            };
            te.captureDiffContextMenuTarget(te.getEditor(), {
                type: monacoRef().editor.MouseTargetType.CONTENT_TEXT,
                position: { lineNumber: row + 1, column: startColumn + 1 }
            });
            const rangeJson = JSON.stringify(range);
            te.requestSpellSuggestions(word, rangeJson, sourceAnchor);
        },
        requestSpellSuggestions: function (word, rangeJson, sourceAnchor) {
            if (!word || !te.mmAsync || te.isEditorSimple) {
                return;
            }
            te.hideHoverTooltipImmediately(sourceAnchor);
            te.dismissHoverTooltip(function () {
                setTimeout(function () {
                    te.mmAsync.GetSuggestions(word, null, false, rangeJson);
                }, 0);
            });
        },
        hideHoverTooltipImmediately: function (sourceAnchor) {
            const hidden = [];

            const hideNode = function (node) {
                if (!node) {
                    return;
                }
                node.classList.add("mm-hover-force-hidden");
                hidden.push(node);
            };

            if (sourceAnchor && sourceAnchor.closest) {
                hideNode(sourceAnchor.closest(".monaco-hover"));
            }

            const hoverNodes = document.querySelectorAll(".monaco-hover");
            for (let i = 0; i < hoverNodes.length; i++) {
                hideNode(hoverNodes[i]);
            }

            // Cleanup in case Monaco keeps/reuses the same hover node.
            setTimeout(function () {
                for (let i = 0; i < hidden.length; i++) {
                    hidden[i].classList.remove("mm-hover-force-hidden");
                }
            }, 1500);
        },
        dismissHoverTooltip: function (callback) {
            const editor = te.getEditor();
            if (!editor) {
                if (typeof callback === "function") {
                    callback();
                }
                return;
            }

            try {
                if (typeof editor.trigger === "function") {
                    editor.trigger("keyboard", "closeHover", null);
                }
            } catch (_) { }

            try {
                if (typeof editor.getAction === "function") {
                    const closeHover = editor.getAction("closeHover");
                    if (closeHover && typeof closeHover.run === "function") {
                        closeHover.run();
                    }
                }
            } catch (_) { }

            setTimeout(function () {
                if (typeof callback === "function") {
                    callback();
                }
            }, 25);
        },
        addWordSpelling: function (word) {
            if (te.mmAsync) {
                te.mmAsync.AddWordToDictionary(word, null)
                    .then(function () { te.spellcheckDocument(true); });
            }
        },
        replaceSpellRange: function (range, text) {
            te.runWhenReady(function() {                
                const editor = te.getEditor();
                const model = te.model;
                if (!editor || !model) {
                    return;
                }

                if (typeof range === "string") {
                    try {
                        range = JSON.parse(range);
                    } catch (_) {
                        range = null;
                    }
                }

                let monacoRange = null;
                if (range) {
                    monacoRange = parseRangeArgs(range);
                }

                if (!monacoRange) {
                    return;
                }

                const replacement = text || "";
                const lineCount = model.getLineCount();
                const startLine = Math.max(1, Math.min(lineCount, monacoRange.startLineNumber || 1));
                const endLine = Math.max(startLine, Math.min(lineCount, monacoRange.endLineNumber || startLine));
                const startMaxColumn = model.getLineMaxColumn(startLine);
                const endMaxColumn = model.getLineMaxColumn(endLine);
                let startColumn = Math.max(1, Math.min(startMaxColumn, monacoRange.startColumn || 1));
                let endColumn = Math.max(startColumn + 1, Math.min(endMaxColumn, monacoRange.endColumn || (startColumn + 1)));
                if (startLine === endLine && range && range.misspelled) {
                    const resolved = resolveSpellRangeOnLine(model, startLine, startColumn, String(range.misspelled));
                    if (resolved) {
                        startColumn = resolved.startColumn;
                        endColumn = resolved.endColumn;
                    }
                }

                const safeRange = {
                    startLineNumber: startLine,
                    startColumn: startColumn,
                    endLineNumber: endLine,
                    endColumn: endColumn
                };

                try {
                    editor.focus();
                    editor.pushUndoStop();
                    const didReplace = editor.executeEdits("mm-replaceSpellRange", [{
                        range: safeRange,
                        text: replacement,
                        forceMoveMarkers: true
                    }], []);
                    if (!didReplace) {
                        return;
                    }
                    editor.pushUndoStop();
                } catch (err) {
                    if (te.mm && typeof te.mm.LogError === "function") {
                        te.mm.LogError("replaceSpellRange executeEdits failed: " + (err && err.message ? err.message : err));
                    }
                    return;
                }

                const endPos = model.getPositionAt(
                    model.getOffsetAt({
                        lineNumber: safeRange.startLineNumber,
                        column: safeRange.startColumn
                    }) + replacement.length
                );
                editor.setSelection({
                    startLineNumber: safeRange.startLineNumber,
                    startColumn: safeRange.startColumn,
                    endLineNumber: endPos.lineNumber,
                    endColumn: endPos.column
                });

                te.spellcheckContentModified = true;
                te.scheduleSpellcheck(true);
            });
        },
        gotfocus: function () {
            te.setfocus();
        },
        setfocus: function () {
            setTimeout(function () {
                const editor = te.getEditor();
                if (editor) {
                    editor.focus();
                }
            }, 50);
        },
        losefocus: function () {
            const editor = te.getEditor();
            if (editor) {
                editor.trigger("keyboard", "blur", null);
            }
        },
        onBlur: function () {
            if (te.mmAsync) {
                te.mmAsync.LostFocus();
            }
        },
        onGotFocus: function () {
            if (te.mmAsync) {
                te.mmAsync.GotFocus();
            }
        },
        blurEditorAndRefocus: function (mstimeout) {
            const timeout = mstimeout || 50;
            te.noRefreshPreview = true;
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            editor.trigger("keyboard", "blur", null);
            setTimeout(function () {
                editor.focus();
                te.noRefreshPreview = false;
            }, timeout);
        },
        adjustPadding: function () {            
            const maxWidth = te.getCenteredModeMaxWidth();
            
            te.applyCenteredSurfaceLayout(te.surface1);
            te.applyCenteredSurfaceLayout(te.surface2);
                       
            te.updateAllEditors(function (editor) {
                editor.updateOptions({ padding: { maxEditorCanvasWidth: maxWidth } });
                editor.layout();
            });
            if (te.diffEditor) {
                te.diffEditor.updateOptions({ padding: { maxEditorCanvasWidth: maxWidth } });
                te.diffEditor.layout();
            }
        },
        execcommand: function (cmd) {
            const editor = te.getEditor();
            if (!editor) {
                return;
            }
            const actionMap = {
                undo: "undo",
                redo: "redo",
                outdent: "outdentLines",
                indent: "editor.action.indentLines"
            };

            const action = actionMap[cmd];
            if (action) {
                if (action === "undo") {
                    te._isUndoRedoOperation = true;
                    setTimeout(function () {
                        te._isUndoRedoOperation = false;
                    }, 150);

                    if (te._changeCount > 0) {
                        te._changeCount--;
                        te._redoCount++;
                    }

                    editor.focus();
                    editor.trigger("keyboard", "undo", null);
                    te.spellcheckContentModified = true;
                    te.scheduleSpellcheck(true);
                } else if (action === "redo") {
                    te._isUndoRedoOperation = true;
                    setTimeout(function () {
                        te._isUndoRedoOperation = false;
                    }, 150);

                    if (te._redoCount > 0) {
                        te._redoCount--;
                        te._changeCount++;
                    }

                    editor.focus();
                    editor.trigger("keyboard", "redo", null);
                    te.spellcheckContentModified = true;
                    te.scheduleSpellcheck(true);
                } else {
                    editor.getAction(action).run();
                }
                return;
            }

            editor.trigger("keyboard", cmd, null);
        },
        hasUndo: function () {
            const editor = te.getEditor();
            const model = editor && editor.getModel ? editor.getModel() : null;
            if (model && typeof model.canUndo === "function") {
                return model.canUndo();
            }
            return te._changeCount > 0;
        },
        hasRedo: function () {
            const editor = te.getEditor();
            const model = editor && editor.getModel ? editor.getModel() : null;
            if (model && typeof model.canRedo === "function") {
                return model.canRedo();
            }
            return te._redoCount > 0;
        },
        split: function (value) {
            te.runWhenReady(function () {
                if (te.isDiffMode) {
                    if (value === "Below" || value === "Beside") {
                        te.closeDiffView();
                    } else {
                        return;
                    }
                }

                if (value === "Below" || value === "Beside") {
                    if (!te.editor2) {
                        const options = te.getEditorOptions(te.lastStyle || te.settings);
                        te.editor2 = monacoRef().editor.create(te.surface2 || te.pane2, Object.assign({}, options, { model: te.model }));
                        te.attachEditorEvents(te.editor2);
                        te.attachDropEvents(te.editor2);
                    }
                    te.applySplitLayout(value);
                    te.editor = te.editor2;
                } else {
                    te.applySplitLayout("None");
                    te.editor = te.mainEditor;
                }

                te.setfocus();
            });
        },
        applySplitLayout: function (mode) {
            te.splitMode = mode || "None";
            if (!te.editorRoot || !te.pane2) {
                return;
            }

            te.editorRoot.classList.remove("below", "beside", "none");
            if (te.splitMode === "Below") {
                te.editorRoot.classList.add("below");
                te.pane2.classList.remove("hidden");
            } else if (te.splitMode === "Beside") {
                te.editorRoot.classList.add("beside");
                te.pane2.classList.remove("hidden");
            } else {
                te.editorRoot.classList.add("none");
                te.pane2.classList.add("hidden");
            }

            te.refresh();
            te.adjustPadding();
        },
        normalizeDiffViewMode: function (mode) {
            const value = String(mode || "").toLowerCase();
            if (value === "sidebyside" || value === "side-by-side" || value === "side_by_side" || value === "beside") {
                return "SideBySide";
            }
            return "Inline";
        },
        openDiffView: function (originalText, modifiedText, viewMode, isRecoveryMode) {
            te.runWhenReady(function () {
                const baseText = typeof originalText === "string" ? originalText : "";
                const currentText = typeof modifiedText === "string" ? modifiedText : te.getvalue();
                const style = te.lastStyle || te.settings || {};
                const requestedMode = te.normalizeDiffViewMode(viewMode);
                const language = te.model && typeof te.model.getLanguageId === "function"
                    ? te.model.getLanguageId()
                    : "markdown";

                te.disposeEditors();
                te.diffViewMode = requestedMode;

                te.model = monacoRef().editor.createModel(currentText, language);
                te.diffOriginalModel = monacoRef().editor.createModel(baseText, language);
                te.diffEditor = monacoRef().editor.createDiffEditor(
                    te.surface1 || te.pane1,
                    te.getDiffEditorOptions(style)
                );
                te.diffEditor.setModel({
                    original: te.diffOriginalModel,
                    modified: te.model
                });

                te.mainEditor = te.diffEditor.getModifiedEditor();
                te.editor = te.mainEditor;
                te.editor2 = null;
                te.isDiffMode = true;
                te.isRecoveryMode = isRecoveryMode === true;
                if (te.isRecoveryMode) {
                    te.recoveryOriginalText = baseText;
                    te.showRecoveryBar();
                }
                te.disposerBag.push(te.diffEditor.onDidUpdateDiff(function () {
                    // Monaco retains the previous line mappings while recomputing.
                    // Only use mappings belonging to these exact model versions.
                    te.diffSnapshot = {
                        originalVersion: te.diffOriginalModel.getVersionId(),
                        modifiedVersion: te.model.getVersionId(),
                        changes: te.diffEditor.getLineChanges() || []
                    };
                }));
                te.applySplitLayout("None");

                te.configureEvents();
                te.setEditorStyle(style);
                te.setfocus();
                if (te.isRecoveryMode) {
                    te.updateDocument();
                }
                te.updateDocumentStats();
                te.refreshPreview();
            });
        },
        closeDiffView: function (viewState) {
            te.runWhenReady(function () {
                if (!te.isDiffMode) {
                    return;
                }

                const editorViewState = viewState || te.diffEditor.getModifiedEditor().saveViewState();
                const style = te.lastStyle || te.settings || {};
                const text = te.model ? te.model.getValue() : "";
                const language = te.model && typeof te.model.getLanguageId === "function"
                    ? te.model.getLanguageId()
                    : "markdown";

                te.disposeEditors();
                // Rebuild the editor host surfaces to ensure no diff widget DOM/input
                // handlers survive into the recreated single editor instance.
                te.ensureEditorLayout();
                te.createSingleEditor(text, language, style);
                te.configureEvents();
                te.setEditorStyle(style);
                if (editorViewState) {
                    te.mainEditor.restoreViewState(editorViewState);
                    te.mainEditor.revealPositionInCenterIfOutsideViewport(te.mainEditor.getPosition());
                }
                te.setfocus();
                te.updateDocumentStats();
                te.refreshPreview();
            });
        },
        setDiffViewMode: function (mode) {
            te.runWhenReady(function () {
                if (!te.diffEditor) {
                    return;
                }
                te.diffViewMode = te.normalizeDiffViewMode(mode);
                te.diffEditor.updateOptions({
                    renderSideBySide: te.diffViewMode === "SideBySide"
                });
                te.refresh();
            });
        },
        keepDiffHunk: function (useContextMenuPosition) {
            te.runWhenReady(function () {
                te.resolveDiffHunk("keep", useContextMenuPosition);
            });
        },
        rejectDiffHunk: function (useContextMenuPosition) {
            te.runWhenReady(function () {
                te.resolveDiffHunk("reject", useContextMenuPosition);
            });
        },
        keepAllDiffChanges: function () {
            te.runWhenReady(function () {
                te.applyKeepAllDiffChanges();
            });
        },
        rejectAllDiffChanges: function () {
            te.runWhenReady(function () {
                te.applyRejectAllDiffChanges();
            });
        },
        acceptDiffChangesAndOpenEditor: function () {
            te.runWhenReady(function () {
                if (!te.isDiffMode) {
                    return;
                }
                te.closeDiffView();
            });
        },
        revertDiffChangesAndOpenEditor: function () {
            te.runWhenReady(function () {
                if (!te.isDiffMode) {
                    return;
                }
                const viewState = te.diffEditor.getModifiedEditor().saveViewState();
                te.applyRejectAllDiffChanges(te.isRecoveryMode ? te.recoveryOriginalText : undefined);
                te.closeDiffView(viewState);
            });
        },
        applyKeepAllDiffChanges: function () {
            if (!te.isDiffMode || !te.diffOriginalModel || !te.model) {
                return;
            }
            te.diffOriginalModel.pushEditOperations([], [{
                range: te.diffOriginalModel.getFullModelRange(),
                text: te.model.getValue()
            }], function () { return null; });
        },
        applyRejectAllDiffChanges: function (originalText) {
            if (!te.isDiffMode || !te.diffOriginalModel || !te.model) {
                return;
            }
            te.model.pushEditOperations([], [{
                range: te.model.getFullModelRange(),
                text: typeof originalText === "string" ? originalText : te.diffOriginalModel.getValue()
            }], function () { return null; });
            te.updateDocument();
            te.refreshPreview();
        },
        resolveDiffHunk: function (action, useContextMenuPosition) {
            if (!te.isDiffMode || !te.diffEditor || !te.model || !te.diffOriginalModel) {
                return;
            }

            const change = te.getCurrentDiffLineChange(useContextMenuPosition);
            if (!change) {
                status(te.getCurrentDiffSnapshot()
                    ? "No diff change at this position."
                    : "Diff is updating. Please try again.");
                return;
            }

            const sourceModel = action === "keep" ? te.model : te.diffOriginalModel;
            const targetModel = action === "keep" ? te.diffOriginalModel : te.model;
            const sourceStart = action === "keep" ? change.modifiedStartLineNumber : change.originalStartLineNumber;
            const sourceEnd = action === "keep" ? change.modifiedEndLineNumber : change.originalEndLineNumber;
            const targetStart = action === "keep" ? change.originalStartLineNumber : change.modifiedStartLineNumber;
            const targetEnd = action === "keep" ? change.originalEndLineNumber : change.modifiedEndLineNumber;

            const lines = [];
            for (let line = sourceStart; sourceEnd > 0 && line <= sourceEnd; line++) {
                lines.push(sourceModel.getLineContent(line));
            }
            const edit = getDiffLineEdit(targetModel, targetStart, targetEnd, lines);
            targetModel.pushEditOperations([], [edit], function () { return null; });

            if (action === "reject") {
                te.updateDocument();
                te.refreshPreview();
            }
        },
        getCurrentDiffLineChange: function (useContextMenuPosition) {
            const snapshot = te.getCurrentDiffSnapshot();
            if (!snapshot) {
                return null;
            }
            const lineChanges = snapshot.changes;
            const editor = te.getEditor();
            let pos = editor ? editor.getPosition() : null;
            let originalSide = false;
            if (useContextMenuPosition) {
                const target = te.diffContextMenuTarget;
                if (!target || target.originalVersion !== snapshot.originalVersion ||
                    target.modifiedVersion !== snapshot.modifiedVersion) {
                    return null;
                }
                pos = target.position;
                originalSide = target.originalSide;
                // Deleted inline text is a view zone, not the unchanged line next to it.
                if (target.deletedAfterLineNumber !== null) {
                    return lineChanges.find(change => change.originalEndLineNumber > 0 &&
                        (change.modifiedEndLineNumber === 0
                            ? change.modifiedStartLineNumber === target.deletedAfterLineNumber
                            : change.modifiedStartLineNumber <= target.deletedAfterLineNumber + 1 &&
                                change.modifiedEndLineNumber >= target.deletedAfterLineNumber + 1)) || null;
                }
            }
            if (!pos) {
                return null;
            }
            const lineNumber = pos.lineNumber;

            for (let i = 0; i < lineChanges.length; i++) {
                const change = lineChanges[i];
                const start = originalSide ? change.originalStartLineNumber : change.modifiedStartLineNumber;
                const end = originalSide ? change.originalEndLineNumber : change.modifiedEndLineNumber;
                if (start > 0 && end >= start && lineNumber >= start && lineNumber <= end) {
                    return change;
                }
            }

            return null;
        },
        getCurrentDiffSnapshot: function () {
            const snapshot = te.diffSnapshot;
            if (!te.isDiffMode || !snapshot ||
                snapshot.originalVersion !== te.diffOriginalModel.getVersionId() ||
                snapshot.modifiedVersion !== te.model.getVersionId()) {
                return null;
            }
            return snapshot;
        },
        captureDiffContextMenuTarget: function (editor, target) {
            te.diffContextMenuTarget = null;
            const snapshot = te.getCurrentDiffSnapshot();
            if (!snapshot || !target) {
                return;
            }
            let deletedAfterLineNumber = null;
            if (target.type === monacoRef().editor.MouseTargetType.CONTENT_VIEW_ZONE) {
                const zone = editor.getDomNode().querySelector(
                    ".line-delete[monaco-view-zone='" + CSS.escape(target.detail.viewZoneId) + "']");
                if (!zone) {
                    return;
                }
                deletedAfterLineNumber = target.detail.positionBefore
                    ? target.detail.positionBefore.lineNumber : 0;
            }
            te.diffContextMenuTarget = {
                position: target.position,
                originalSide: editor.getModel() === te.diffOriginalModel,
                deletedAfterLineNumber: deletedAfterLineNumber,
                originalVersion: snapshot.originalVersion,
                modifiedVersion: snapshot.modifiedVersion
            };
        },
        hasCurrentDiffChange: function (useContextMenuPosition) {
            return !!te.getCurrentDiffLineChange(useContextMenuPosition);
        },
        isdiffmode: function () {
            return !!te.isDiffMode;
        },
        getdiffviewmode: function () {
            return te.diffViewMode || "Inline";
        },
        registerDiffHunkToolbarActions: function () {
            if (te.diffToolbarActionsRegistered || typeof window.require !== "function") {
                return;
            }

            window.require([
                "vs/platform/actions/common/actions",
                "vs/platform/commands/common/commands",
                "vs/editor/common/editorContextKeys"
            ], function (actionsModule, commandsModule, editorContextKeysModule) {
                if (te.diffToolbarActionsRegistered) {
                    return;
                }

                const menuRegistry = actionsModule && actionsModule.MenuRegistry;
                const menuId = actionsModule && actionsModule.MenuId && actionsModule.MenuId.DiffEditorHunkToolbar;
                const commandRegistry = commandsModule && commandsModule.CommandsRegistry;
                const editorContextKeys = editorContextKeysModule && editorContextKeysModule.EditorContextKeys;
                if (!menuRegistry || !menuId || !commandRegistry) {
                    return;
                }

                const whenWritable = editorContextKeys && editorContextKeys.diffEditorModifiedWritable
                    ? editorContextKeys.diffEditorModifiedWritable
                    : undefined;

                te.registerMonacoCommand(commandRegistry, "markdownMonster.diff.revertAllChanges", function () {
                    te.rejectAllDiffChanges();
                });
                te.registerMonacoCommand(commandRegistry, "markdownMonster.diff.acceptAndOpenStandardEditor", function () {
                    te.acceptDiffChangesAndOpenEditor();
                });
                te.registerMonacoCommand(commandRegistry, "markdownMonster.diff.revertAndOpenStandardEditor", function () {
                    te.revertDiffChangesAndOpenEditor();
                });

                menuRegistry.appendMenuItem(menuId, {
                    command: {
                        id: "markdownMonster.diff.revertAllChanges",
                        title: "Revert All Changes"
                    },
                    when: whenWritable,
                    group: "secondary",
                    order: 40
                });
                menuRegistry.appendMenuItem(menuId, {
                    command: {
                        id: "markdownMonster.diff.acceptAndOpenStandardEditor",
                        title: "Accept Changes and Open in Standard Editor"
                    },
                    when: whenWritable,
                    group: "secondary",
                    order: 41
                });
                menuRegistry.appendMenuItem(menuId, {
                    command: {
                        id: "markdownMonster.diff.revertAndOpenStandardEditor",
                        title: "Revert Changes and Open in Standard Editor"
                    },
                    when: whenWritable,
                    group: "secondary",
                    order: 42
                });

                te.diffToolbarActionsRegistered = true;
            });
        },
        registerMonacoCommand: function (registry, id, handler) {
            if (!registry || !id || typeof handler !== "function") {
                return;
            }
            if (te.registeredMonacoCommands[id]) {
                return;
            }
            if (typeof registry.getCommand === "function" && registry.getCommand(id)) {
                te.registeredMonacoCommands[id] = true;
                return;
            }
            registry.registerCommand(id, function () {
                handler();
            });
            te.registeredMonacoCommands[id] = true;
        },
        returnFalse: function () { return false; },

        // Helpers exposed for compatibility
        getLineCount: function () {
            return te.model ? te.model.getLineCount() : 0;
        },
        runWhenReady: function (callback) {
            if (te.isReady) {
                callback();
                return;
            }
            te.pendingOperations.push(callback);
        },
        flushPendingOperations: function () {
            while (te.pendingOperations.length > 0) {
                const op = te.pendingOperations.shift();
                try {
                    op();
                } catch (_) { }
            }
        },
        getEditor: function () {
            return te.editor || te.mainEditor;
        },
        getCenteredModeMaxWidth: function (style) {
            style = style || te.lastStyle || te.settings || {};
            const value = parseInt(style.maxWidth || 0, 10);
            return Math.max(0, Number.isNaN(value) ? 0 : value);
        },
        applyCenteredSurfaceLayout: function (surface) {
            if (!surface) {
                return;
            }
            
            surface.style.maxWidth = "none";
            surface.style.width = "100%";
            surface.style.marginLeft = "0";
            surface.style.marginRight = "0";
        },
        updateAllEditors: function (updater) {
            if (te.mainEditor) {
                updater(te.mainEditor);
            }
            if (te.editor2) {
                updater(te.editor2);
            }
            if (te.diffEditor) {
                const originalEditor = te.diffEditor.getOriginalEditor();
                if (originalEditor) {
                    updater(originalEditor);
                }
            }
        },
        mapTheme: function (theme) {
            if (window.mmMonacoThemes &&
                typeof window.mmMonacoThemes.resolveThemeName === "function") {
                return window.mmMonacoThemes.resolveThemeName(theme);
            }

            const name = (theme || "").toLowerCase();
            return name.indexOf("light") > -1 ? "vs" : "vs-dark";
        },
        setlanguage: function (lang) {
            te.runWhenReady(function () {
                if (!te.model) {
                    return;
                }
                const mapped = mapLanguage(lang);
                monacoRef().editor.setModelLanguage(te.model, mapped);
                if (te.diffOriginalModel) {
                    monacoRef().editor.setModelLanguage(te.diffOriginalModel, mapped);
                }
            });
        },
        setEditorStyle: function (styleJson) {
            let style = null;
            if (typeof styleJson === "object") {
                style = styleJson;
            } else {
                style = JSON.parse(styleJson);
            }

            // console.log("setEditorStyle called with:", style);

            te.settings = style;
            te.lastStyle = style;
            te.spellcheckUseMonacoAssist = !!editorSettings.enableMonacoSpellcheckAssist;

            monacoRef().editor.setTheme(te.mapTheme(style.theme));

            const fontSize = parseInt(style.fontSize || 16, 10);
            const lineHeight = Math.max(14, Math.round(fontSize * parseFloat(style.lineHeight || 1.45)));
            const scrollbarSize = 8;

            te.updateAllEditors(function (editor) {
                editor.updateOptions({
                    fontFamily: style.font || "Consolas",
                    fontSize: fontSize,
                    lineHeight: lineHeight,
                    lineNumbers: style.showLineNumbers ? "on" : "off",
                    renderWhitespace: style.showInvisibles ? "all" : "selection",
                    renderControlCharacters: style.showInvisibles ? true : false,
                    renderFinalNewline: style.showInvisibles ? "on" : "off",
                    renderLineHighlight: style.highlightActiveLine ? "line" : "none",
                    wordWrap: style.wrapText ? "on" : "off",
                    minimap: { enabled: style.showMiniMap ? true : false },                    
                    scrollbar: {
                        verticalScrollbarSize: scrollbarSize,
                        horizontalScrollbarSize: scrollbarSize,
                        useShadows: false
                    },
                    guides: {
                        indentation: style.showInvisibles,
                        highlightActiveIndentation: style.showInvisibles
                    }
                });
            });

            if (te.diffEditor) {
                te.diffEditor.updateOptions({
                    renderSideBySide: te.diffViewMode === "SideBySide",
                    originalEditable: false,
                    enableSplitViewResizing: true
                });
            }
            te.applySpellAssistOptions();

            if (te.recoveryBar) {
                const colors = window.getComputedStyle(te.mainEditor.getDomNode());
                te.recoveryBar.style.backgroundColor = colors.backgroundColor;
                te.recoveryBar.style.color = colors.color;
            }
            te.adjustPadding();
            setTimeout(te.updateDocumentStats, 30);
        },
        moveCursorOffset: function (offset) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return;
            }
            const pos = editor.getPosition();
            if (!pos) {
                return;
            }
            const current = model.getOffsetAt(pos);
            const target = Math.max(0, Math.min(model.getValueLength(), current + offset));
            editor.setPosition(model.getPositionAt(target));
        },
        moveCursorLineOffset: function (lineOffset) {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return;
            }
            const pos = editor.getPosition();
            if (!pos) {
                return;
            }
            const line = Math.max(1, Math.min(model.getLineCount(), pos.lineNumber + lineOffset));
            const col = Math.max(1, Math.min(model.getLineMaxColumn(line), pos.column));
            editor.setPosition({ lineNumber: line, column: col });
            editor.revealLineInCenter(line);
        },
        getVisibleRows: function (editor) {
            if (!editor) {
                return null;
            }
            const ranges = editor.getVisibleRanges();
            if (!ranges || ranges.length === 0) {
                return null;
            }
            const range = ranges[0];
            return {
                firstRow: range.startLineNumber - 1,
                lastRow: range.endLineNumber - 1
            };
        },
        getEditorRatio: function () {
            const editor = te.getEditor();
            if (!editor) {
                return 0.1;
            }
            const vis = te.getVisibleRows(editor);
            if (!vis) {
                return 0.1;
            }
            const pos = editor.getPosition();
            const cursor = pos && pos.lineNumber ? pos.lineNumber - 1 : vis.firstRow;
            const ratio = (cursor - vis.firstRow) / Math.max(1, vis.lastRow - vis.firstRow);
            const clamped = Math.max(0, Math.min(1, ratio));
            return clamped === 0 ? 0.1 : clamped;
        },
        clearSpellcheckMarkers: function () {
            if (te.model) {
                te.spellcheckDecorationIds = te.model.deltaDecorations(te.spellcheckDecorationIds, []);
                monacoRef().editor.setModelMarkers(te.model, te.spellcheckMarkerOwner, []);
            }
            te.spellcheckWords = [];
        },
        collectMisspellings: function () {
            const model = te.model;
            const editor = te.getEditor();
            if (!model || !editor) {
                return [];
            }

            const vis = te.getVisibleRows(editor);
            if (!vis) {
                return [];
            }

            const viewportRowCount = Math.max(1, (vis.lastRow - vis.firstRow) + 1);
            const marginRows = viewportRowCount;
            const topRow = Math.max(0, vis.firstRow - marginRows);
            const bottomRow = Math.min(model.getLineCount() - 1, vis.lastRow + marginRows);
            const words = [];
            const cursor = te.getCursorPosition();
            const initialState = te.getSpellcheckParseState(topRow);
            let isCodeBlock = initialState.isCodeBlock;
            let isFrontMatter = initialState.isFrontMatter;
            let isPlantUml = initialState.isPlantUml;

            for (let row = topRow; row <= bottomRow; row++) {
                const lineText = model.getLineContent(row + 1) || "";
                if (!lineText) {
                    continue;
                }

                if (lineText.indexOf("]: data:image/") > -1) {
                    continue;
                }

                const trimText = lineText.trim();
                if (isFrontMatter && (trimText === "---" || trimText === "...")) {
                    isFrontMatter = false;
                    continue;
                }
                if (row === 0 && trimText === "---") {
                    isFrontMatter = true;
                    continue;
                }

                if (trimText === "@startuml") {
                    isPlantUml = true;
                    continue;
                }
                if (trimText === "@enduml") {
                    isPlantUml = false;
                    continue;
                }

                if (trimText.startsWith("```")) {
                    isCodeBlock = !isCodeBlock;
                    continue;
                }
                if (isCodeBlock || isFrontMatter || isPlantUml) {
                    continue;
                }

                let skipWord = null;
                if (row === cursor.row) {
                    const pos = toMonacoPos(cursor.row, cursor.column);
                    const wordAtPos = model.getWordAtPosition(pos);
                    skipWord = wordAtPos ? wordAtPos.word : null;
                }

                const misspellings = te.findMisspellingsInLine(lineText, skipWord);
                for (let i = 0; i < misspellings.length; i++) {
                    const bad = misspellings[i];
                    words.push({
                        word: bad.word,
                        startRow: row,
                        endRow: row,
                        startColumn: bad.startColumn,
                        endColumn: bad.endColumn
                    });
                }
            }

            return words;
        },
        getSpellcheckParseState: function (rowExclusive) {
            const model = te.model;
            const state = {
                isCodeBlock: false,
                isFrontMatter: false,
                isPlantUml: false
            };

            if (!model || rowExclusive <= 0) {
                return state;
            }

            const endRowExclusive = Math.min(model.getLineCount(), Math.max(0, rowExclusive));
            for (let row = 0; row < endRowExclusive; row++) {
                const lineText = model.getLineContent(row + 1) || "";
                const trimText = lineText.trim();
                if (!trimText) {
                    continue;
                }

                if (state.isFrontMatter && (trimText === "---" || trimText === "...")) {
                    state.isFrontMatter = false;
                    continue;
                }
                if (!state.isFrontMatter && row === 0 && trimText === "---") {
                    state.isFrontMatter = true;
                    continue;
                }

                if (trimText === "@startuml") {
                    state.isPlantUml = true;
                    continue;
                }
                if (trimText === "@enduml") {
                    state.isPlantUml = false;
                    continue;
                }

                if (trimText.startsWith("```")) {
                    state.isCodeBlock = !state.isCodeBlock;
                }
            }

            return state;
        },
        findMisspellingsInLine: function (lineText, skipWord) {
            if (!lineText) {
                return [];
            }

            let text = lineText.replace(/[´’]/g, "'");

            // Ignore inline code and html attrs.
            text = text.replace(/`.*?`|href=".*?"|src=".*?"|class=".*?"|style=".*?"/g, function (match) {
                return new Array(match.length + 1).join("9");
            });
            // Ignore markdown links.
            text = text.replace(/\]\(.*?\)/g, function (match) {
                return " " + new Array(match.length).join("9");
            });
            // Ignore raw urls.
            text = text.replace(/(http|https):\/\/.*?(\s|,|\/\.\s|$)/g, function (match) {
                return new Array(match.trim().length).join("9") + " ";
            });

            const excluded = te.spellcheckExcludedWords.toLowerCase();
            const misses = [];
            const wordRegex = /[A-Za-z\u00C0-\u02AF'’-]+/g;
            let match;

            while ((match = wordRegex.exec(text)) !== null) {
                const rawWord = match[0];
                if (!rawWord) {
                    continue;
                }

                let word = rawWord;
                let start = match.index;
                let end = start + rawWord.length;

                if ((word[0] === "'" || word[0] === "\"") && word.length > 1) {
                    word = word.substr(1);
                    start++;
                }
                if ((word[word.length - 1] === "'" || word[word.length - 1] === "\"") && word.length > 1) {
                    word = word.substr(0, word.length - 1);
                    end--;
                }

                if (!word || word === skipWord) {
                    continue;
                }
                if (word.indexOf("-") > -1 || word === word.toUpperCase()) {
                    continue;
                }
                if (excluded.indexOf("," + word.toLowerCase() + ",") >= 0) {
                    continue;
                }
                if (word.length > 1) {
                    const tail = word.substr(1);
                    if (tail.toLowerCase() !== tail) {
                        continue; // CamelCase-ish words
                    }
                }

                if (!te.checkSpelling(word)) {
                    misses.push({
                        word: word,
                        startColumn: start,
                        endColumn: end
                    });
                }
            }

            return misses;
        },
        applySpellcheckMarkers: function (words) {
            if (!te.model) {
                return;
            }

            const markers = [];
            for (let i = 0; i < words.length; i++) {
                const w = words[i];
                markers.push({
                    severity: monacoRef().MarkerSeverity.Warning,
                    source: "spellcheck",
                    message: "'" + w.word + "' may be misspelled.",
                    code: {
                        value: "Suggestions",
                        target: "mm-spell://suggest?row=" + encodeURIComponent(w.startRow) +
                            "&startColumn=" + encodeURIComponent(w.startColumn) +
                            "&endColumn=" + encodeURIComponent(w.endColumn) +
                            "&word=" + encodeURIComponent(w.word)
                    },
                    startLineNumber: w.startRow + 1,
                    startColumn: w.startColumn + 1,
                    endLineNumber: w.endRow + 1,
                    endColumn: Math.max(w.startColumn + 2, w.endColumn + 1)
                });
            }

            // Keep an empty decoration set so legacy state stays consistent,
            // but render visible underlines through Monaco markers (reliable across themes/token spans).
            te.spellcheckDecorationIds = te.model.deltaDecorations(te.spellcheckDecorationIds, []);
            monacoRef().editor.setModelMarkers(te.model, te.spellcheckMarkerOwner, markers);
        },
        moveToSpellcheckError: function (direction) {
            const editor = te.getEditor();
            if (!editor || !te.spellcheckWords || te.spellcheckWords.length === 0) {
                return;
            }

            const currentOffset = te.getCharacterOffset();
            let target = null;

            if (direction > 0) {
                for (let i = 0; i < te.spellcheckWords.length; i++) {
                    const item = te.spellcheckWords[i];
                    const offset = te.model.getOffsetAt(toMonacoPos(item.startRow, item.startColumn));
                    if (offset > currentOffset) {
                        target = item;
                        break;
                    }
                }
                if (!target) {
                    target = te.spellcheckWords[0];
                }
            } else {
                for (let i = te.spellcheckWords.length - 1; i >= 0; i--) {
                    const item = te.spellcheckWords[i];
                    const offset = te.model.getOffsetAt(toMonacoPos(item.startRow, item.startColumn));
                    if (offset < currentOffset) {
                        target = item;
                        break;
                    }
                }
                if (!target) {
                    target = te.spellcheckWords[te.spellcheckWords.length - 1];
                }
            }

            const range = toMonacoRange(target.startRow, target.startColumn, target.endRow, target.endColumn);
            editor.setSelection(range);
            editor.revealRangeInCenter(range);
        },
        positionToScreenPoint: function (position) {
            const editor = te.getEditor();
            if (!editor) {
                return { x: 0, y: 0 };
            }
            if (!position) {
                position = editor.getPosition();
            }

            const p = editor.getScrolledVisiblePosition(position);
            const rect = editor.getDomNode().getBoundingClientRect();
            if (!p) {
                return { x: Math.round(rect.left + 20), y: Math.round(rect.top + 20) };
            }
            return {
                x: Math.round(rect.left + p.left),
                y: Math.round(rect.top + p.top + p.height)
            };
        },
        onWheel: function (e) {
            if (!e || !(e.ctrlKey || e.metaKey)) {
                return;
            }
            if (te.editorElement && e.target && !te.editorElement.contains(e.target)) {
                return;
            }
            e.preventDefault();
            if (typeof e.stopPropagation === "function") {
                e.stopPropagation();
            }
            te.requestZoomStep(e.deltaY < 0 ? 1 : -1);
            return false;
        },
        windowResize: function () {
            te.adjustPadding();
        }
    };

    function parseRangeArgs(startRowOrRange, startColumn, endRow, endColumn) {
        if (startRowOrRange && typeof startRowOrRange === "object") {
            const obj = startRowOrRange;
            const startObj = obj.start || obj.Start;
            const endObj = obj.end || obj.End;

            const sRow = startObj ? (startObj.row ?? startObj.Row) : (obj.startRow ?? obj.StartRow);
            const sCol = startObj ? (startObj.column ?? startObj.Column) : (obj.startColumn ?? obj.StartColumn);
            let eRow = endObj ? (endObj.row ?? endObj.Row) : (obj.endRow ?? obj.EndRow);
            let eCol = endObj ? (endObj.column ?? endObj.Column) : (obj.endColumn ?? obj.EndColumn);

            // If end is missing/collapsed, expand by misspelled-word width when available.
            const misspelled = obj.misspelled || obj.word || "";
            if (eRow == null) {
                eRow = sRow;
            }
            if (eCol == null) {
                eCol = (sCol ?? 0) + (misspelled ? String(misspelled).length : 1);
            }

            return toMonacoRange(sRow, sCol, eRow, eCol);
        }

        return toMonacoRange(startRowOrRange, startColumn, endRow, endColumn);
    }

    function getDiffLineEdit(model, startLineNumber, endLineNumber, lines) {
        const lineCount = model.getLineCount();
        const eol = model.getEOL();
        // Empty ranges use the line BEFORE the insertion, including zero at BOF.
        const start = endLineNumber === 0 ? startLineNumber + 1 : startLineNumber;
        const endExclusive = endLineNumber === 0 ? start : endLineNumber + 1;
        const text = lines.join(eol);

        if (endExclusive <= lineCount) {
            return {
                range: {
                    startLineNumber: start, startColumn: 1,
                    endLineNumber: endExclusive, endColumn: 1
                },
                text: lines.length ? text + eol : ""
            };
        }

        // At EOF include the preceding separator instead of a trailing one.
        if (start > 1) {
            return {
                range: {
                    startLineNumber: start - 1, startColumn: model.getLineMaxColumn(start - 1),
                    endLineNumber: lineCount, endColumn: model.getLineMaxColumn(lineCount)
                },
                text: lines.length ? eol + text : ""
            };
        }

        return { range: model.getFullModelRange(), text: text };
    }

    function resolveSpellRangeOnLine(model, lineNumber, startColumn, misspelled) {
        if (!model || !lineNumber || !startColumn || !misspelled) {
            return null;
        }
        const lineText = model.getLineContent(lineNumber) || "";
        if (!lineText) {
            return null;
        }

        const fromIndex = Math.max(0, startColumn - 1);
        if (lineText.substr(fromIndex, misspelled.length) === misspelled) {
            return {
                startColumn: fromIndex + 1,
                endColumn: fromIndex + 1 + misspelled.length
            };
        }

        const nextIndex = lineText.indexOf(misspelled, fromIndex);
        if (nextIndex >= 0) {
            return {
                startColumn: nextIndex + 1,
                endColumn: nextIndex + 1 + misspelled.length
            };
        }

        const prevIndex = lineText.lastIndexOf(misspelled, fromIndex);
        if (prevIndex >= 0) {
            return {
                startColumn: prevIndex + 1,
                endColumn: prevIndex + 1 + misspelled.length
            };
        }

        return null;
    }

    function toMonacoPos(row, column) {
        return {
            lineNumber: Math.max(1, (parseInt(row || 0, 10) + 1)),
            column: Math.max(1, (parseInt(column || 0, 10) + 1))
        };
    }

    function fromMonacoPos(pos) {
        if (!pos || typeof pos.lineNumber !== "number") {
            return { row: 0, column: 0 };
        }
        return {
            row: (pos.lineNumber || 1) - 1,
            column: (pos.column || 1) - 1
        };
    }

    function toMonacoRange(startRow, startColumn, endRow, endColumn) {
        const sRow = parseInt(startRow ?? 0, 10);
        const sCol = parseInt(startColumn ?? 0, 10);
        let eRow = parseInt(endRow ?? sRow, 10);
        let eCol = parseInt(endColumn, 10);

        const safeStartRow = Number.isFinite(sRow) ? sRow : 0;
        const safeStartCol = Number.isFinite(sCol) ? sCol : 0;
        const safeEndRow = Number.isFinite(eRow) ? eRow : safeStartRow;

        if (!Number.isFinite(eCol)) {
            eCol = safeStartCol + 1;
        }

        let safeEndCol = eCol;
        if (safeEndRow === safeStartRow && safeEndCol <= safeStartCol) {
            safeEndCol = safeStartCol + 1;
        }

        return {
            startLineNumber: Math.max(1, safeStartRow + 1),
            startColumn: Math.max(1, safeStartCol + 1),
            endLineNumber: Math.max(1, safeEndRow + 1),
            endColumn: Math.max(1, safeEndCol + 1)
        };
    }

    function fromMonacoRange(range) {
        if (!range) {
            return {
                startRow: 0,
                endRow: 0,
                startColumn: 0,
                endColumn: 0
            };
        }
        return {
            startRow: range.startLineNumber - 1,
            endRow: range.endLineNumber - 1,
            startColumn: range.startColumn - 1,
            endColumn: range.endColumn - 1
        };
    }

    function mapLanguage(lang) {
        if (!lang) {
            return "plaintext";
        }
        const key = (lang + "").toLowerCase();
        const map = {
            markdown: "markdown",
            md: "markdown",
            txt: "plaintext",
            text: "plaintext",
            none: "plaintext",
            plain: "plaintext",
            csharp: "csharp",
            "c#": "csharp",
            cs: "csharp",
            c_cpp: "cpp",
            "c++": "cpp",
            cpp: "cpp",
            javascript: "javascript",
            js: "javascript",
            typescript: "typescript",
            ts: "typescript",
            json: "json",
            html: "html",
            xml: "xml",
            css: "css",
            sql: "sql",
            python: "python",
            powershell: "powershell",
            ps: "powershell",
            bash: "shell",
            shell: "shell",
            yml: "yaml",
            yaml: "yaml",            
            foxpro: "foxpro",
            vfp: "foxpro",
            prg: "foxpro",
            text: "plaintext",

            http: "http"
        };
        return map[key] || key;
    }

    function normalizeShortcut(shortcut) {
        if (!shortcut) {
            return null;
        }

        let parts = shortcut.replace(/\s+/g, "").split(/[\+\-]/g);
        if (!parts || parts.length === 0) {
            return null;
        }

        const mods = [];
        let key = null;

        for (let i = 0; i < parts.length; i++) {
            const token = (parts[i] || "").toLowerCase();
            if (!token) {
                continue;
            }
            if (token === "ctrl" || token === "control") {
                mods.push("ctrl");
            } else if (token === "shift") {
                mods.push("shift");
            } else if (token === "alt") {
                mods.push("alt");
            } else if (token === "cmd" || token === "win" || token === "meta") {
                mods.push("meta");
            } else {
                key = normalizeKeyName(token);
            }
        }

        mods.sort();
        if (!key) {
            return null;
        }
        mods.push(key);
        return mods.join("+");
    }

    function normalizeEventShortcut(evt) {
        if (!evt || !evt.key) {
            return null;
        }

        const mods = [];
        if (evt.ctrlKey) mods.push("ctrl");
        if (evt.shiftKey) mods.push("shift");
        if (evt.altKey) mods.push("alt");
        if (evt.metaKey) mods.push("meta");

        const key = normalizeKeyName(evt.key.toLowerCase());
        if (!key) {
            return null;
        }

        mods.sort();
        mods.push(key);
        return mods.join("+");
    }

    function normalizeKeyName(name) {
        const map = {
            arrowup: "up",
            arrowdown: "down",
            arrowleft: "left",
            arrowright: "right",
            escape: "esc",
            " ": "space",
            plus: "="
        };
        return map[name] || name;
    }

    window.onerror = function windowError(message, filename, lineno, colno, error) {
        let msg = "";
        if (message) msg = message;
        if (filename) msg += ", " + filename;
        if (lineno) msg += " (" + lineno + "," + colno + ")";
        if (error) msg += " " + error;

        if (editorSettings.isDebug) {
            status(msg);
        }

        if (window.textEditor) {
            window.textEditor.lastError = msg;
        }

        if (console && console.log) {
            console.log(msg, filename, lineno, colno, error);
        }
        return true;
    };

    // Context menu is handled exclusively via the DOM 'contextmenu' listener
    // attached in attachDropEvents. window.oncontextmenu is intentionally not used.

    let statusTimeout = null;
    const statusDefaultTimeout = 10000;
    function status(msg, append, timeout) {
        const limit = timeout || statusDefaultTimeout;
        let el = document.getElementById("StatusMessage");
        if (!el) {
            el = document.createElement("div");
            el.id = "StatusMessage";
            document.body.appendChild(el);
        }

        if (!msg) {
            el.style.display = "none";
            return;
        }

        const dt = new Date();
        msg = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds() + "." + Math.floor(dt.getMilliseconds()) + ": " + msg;

        if (!append) {
            el.innerText = msg;
        } else {
            const old = el.innerHTML;
            el.innerHTML = old ? old + "<br/>" + msg : msg;
        }

        el.style.display = "block";
        if (statusTimeout) {
            clearTimeout(statusTimeout);
        }
        statusTimeout = setTimeout(function () {
            statusTimeout = null;
            el.style.display = "none";
            el.innerText = "";
        }, limit);
    }
})();

function initializeinterop(jsonStyle) {
    // console.log("initializeinterop called");
    // console.dir(jsonStyle);

    const te = window.textEditor;
    if (window.chrome && window.chrome.webview && window.chrome.webview.hostObjects) {
        te.mm = window.chrome.webview.hostObjects.sync.mm;
        te.mmAsync = window.chrome.webview.hostObjects.mm;
    }

    let style = editorSettings;
    if (jsonStyle) {
        style = JSON.parse(jsonStyle);
    }

    te.isEditorSimple = false;
    te.initialize(style);
}

function initializeinteropSimple(jsonStyle) {
    const te = window.textEditor;
    if (window.chrome && window.chrome.webview && window.chrome.webview.hostObjects) {
        te.mm = window.chrome.webview.hostObjects.sync.mm;
        te.mmAsync = window.chrome.webview.hostObjects.mm;
    }

    let style = editorSettings;
    if (jsonStyle) {
        style = JSON.parse(jsonStyle);
    }

    te.isEditorSimple = true;
    te.initialize(style);
}

function Invoke(teFunction) {
    if (arguments.length < 1) {
        return null;
    }

    const func = eval("window.textEditor." + teFunction);
    if (typeof func !== "function") {
        throw new Error("Invalid Function to Invoke: " + teFunction);
    }

    if (arguments.length > 1) {
        Array.prototype.shift.call(arguments);
    }
    return func.apply(window, arguments);
}

function GetValue(property) {
    return eval("window.textEditor." + property);
}
