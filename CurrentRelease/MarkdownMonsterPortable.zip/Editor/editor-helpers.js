// Global functions and helpers

function debounce(func, wait, immediate) {
  var timeout;
  return function () {
    var context = this, args = arguments;
    var later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow)
      func.apply(context, args);
  };
};

String.prototype.startsWith = function (sub, nocase) {
  if (!this || this.length === 0 || sub === null) return false;

  if (sub && nocase)
    return this.toLowerCase().indexOf(sub.toLowerCase()) === 0;

  return this.indexOf(sub) === 0;
}
String.prototype.endsWith = function (sub, nocase) {
  if (!this || this.length === 0) return false;

  var ix = 0;
  if (sub && nocase) {
    ix = this.toLowerCase().lastIndexOf(sub.toLowerCase());
    if (ix > 0 && ix + sub.length === this.length)
      return true;
    return false;
  }

  ix = this.lastIndexOf(sub);
  if (ix > 0 && ix + sub.length === this.length)
    return true;
  return false;
}
String.prototype.extract = function (startDelim, endDelim, allowMissingEndDelim, returnDelims) {
  var str = this;
  if (str.length === 0)
    return "";

  var src = str.toLowerCase();
  startDelim = startDelim.toLocaleLowerCase();
  endDelim = endDelim.toLocaleLowerCase();

  var i1 = src.indexOf(startDelim);
  if (i1 == -1)
    return "";

  var i2 = src.indexOf(endDelim, i1 + startDelim.length);

  if (!allowMissingEndDelim && i2 == -1)
    return "";

  if (allowMissingEndDelim && i2 == -1) {
    if (returnDelims)
      return str.substr(i1);

    return str.substr(i1 + startDelim.length);
  }

  if (returnDelims)
    return str.substr(i1, i2 - i1 + startDelim.length);

  return str.substr(i1 + startDelim.length, i2 - i1 - startDelim.length);
};

function mmNormalizeColorToHex(colorValue, fallback) {
  if (typeof colorValue !== "string")
    return fallback || null;

  const value = colorValue.trim();
  if (!value)
    return fallback || null;

  const normalizedHex = mmNormalizeHexColor(value);
  if (normalizedHex)
    return normalizedHex;

  try {
    if (!window.__mmColorParseCanvas) {
      const canvas = document.createElement("canvas");
      canvas.width = 1;
      canvas.height = 1;
      window.__mmColorParseCanvas = canvas;
      window.__mmColorParseCtx = canvas.getContext("2d");
    }

    const ctx = window.__mmColorParseCtx;
    if (!ctx)
      return fallback || null;

    const previous = ctx.fillStyle;
    ctx.fillStyle = "#000000";
    ctx.fillStyle = value;
    const parsed = String(ctx.fillStyle || "").trim();
    ctx.fillStyle = previous;

    const parsedHex = mmNormalizeHexColor(parsed) || mmRgbStringToHex(parsed);
    if (parsedHex)
      return parsedHex;
  }
  catch (_) { }

  return fallback || null;
}

function mmColorNameToHex(colorName, fallback) {
  return mmNormalizeColorToHex(colorName, fallback);
}

function mmNormalizeHexColor(value) {
  if (typeof value !== "string")
    return null;

  const input = value.trim().replace(/^#/, "");
  if (!input)
    return null;

  if (/^[0-9a-fA-F]{3}$/.test(input)) {
    return "#" + input.split("").map(function (c) { return c + c; }).join("").toUpperCase();
  }
  if (/^[0-9a-fA-F]{4}$/.test(input)) {
    return "#" + input.split("").map(function (c) { return c + c; }).join("").toUpperCase();
  }
  if (/^[0-9a-fA-F]{6}$/.test(input) || /^[0-9a-fA-F]{8}$/.test(input)) {
    return "#" + input.toUpperCase();
  }

  return null;
}

function mmRgbStringToHex(value) {
  if (typeof value !== "string")
    return null;

  const match = value.trim().match(/^rgba?\(\s*([+\-]?\d*\.?\d+)\s*,\s*([+\-]?\d*\.?\d+)\s*,\s*([+\-]?\d*\.?\d+)\s*(?:,\s*([+\-]?\d*\.?\d+)\s*)?\)$/i);
  if (!match)
    return null;

  const r = mmClampByte(parseFloat(match[1]));
  const g = mmClampByte(parseFloat(match[2]));
  const b = mmClampByte(parseFloat(match[3]));
  const a = match[4] != null ? mmClampAlpha(parseFloat(match[4])) : null;

  const hex = "#" + mmToHexByte(r) + mmToHexByte(g) + mmToHexByte(b);
  if (a == null)
    return hex;

  return hex + mmToHexByte(Math.round(a * 255));
}

function mmClampByte(value) {
  if (isNaN(value))
    return 0;
  if (value < 0)
    return 0;
  if (value > 255)
    return 255;
  return Math.round(value);
}

function mmClampAlpha(value) {
  if (isNaN(value))
    return 1;
  if (value < 0)
    return 0;
  if (value > 1)
    return 1;
  return value;
}

function mmToHexByte(value) {
  const hex = Number(value).toString(16).toUpperCase();
  return hex.length === 1 ? "0" + hex : hex;
}


function installMarkdownListContinuation(editor) {

    const monaco = window.monaco;

    editor.addCommand(monaco.KeyCode.Enter, function () {
        var model = editor.getModel();
        var position = editor.getPosition();
        var selection = editor.getSelection();

        if (!model || !position || !selection) {
            return;
        }

        if (model.getLanguageId && model.getLanguageId() !== "markdown") {
            editor.trigger("keyboard", "type", { text: "\n" });
            return;
        }

        if (!selection.isEmpty()) {
            editor.trigger("keyboard", "type", { text: "\n" });
            return;
        }

        var lineNumber = position.lineNumber;
        var column = position.column;
        var line = model.getLineContent(lineNumber);

        // Only continue list when cursor is at end of line.
        if (column < line.length + 1) {
            editor.trigger("keyboard", "type", { text: "\n" });
            return;
        }

        var result = getNextMarkdownListPrefix(line);

        if (!result) {
            editor.trigger("keyboard", "type", { text: "\n" });
            return;
        }

        if (result.exitList) {
            editor.executeEdits("markdown-list-exit", [{
                range: new monaco.Range(
                    lineNumber,
                    1,
                    lineNumber,
                    line.length + 1
                ),
                text: result.remainingPrefix
            }]);

            editor.setPosition({
                lineNumber: lineNumber,
                column: result.remainingPrefix.length + 1
            });

            editor.trigger("keyboard", "type", { text: "\n" });
            return;
        }

        editor.trigger("keyboard", "type", {
            text: "\n" + result.nextPrefix
        });
    });
}

function getNextMarkdownListPrefix(line) {
    /*
      Supports:
      - item
      * item
      + item
      1. item
      1) item
      - [ ] task
      - [x] task
      > - quoted item
      > 1. quoted ordered item
    */

    var listRegex = /^(\s*(?:>\s*)*)([-+*]|\d{1,9}[.)])(\s+)(?:\[([ xX])\]\s+)?(.*)$/;
    var match = line.match(listRegex);

    if (!match) {
        return null;
    }

    var quoteAndIndent = match[1] || "";
    var marker = match[2];
    var spacing = match[3] || " ";
    var taskState = match[4];
    var text = match[5] || "";

    var isTask = taskState !== undefined;
    var isEmptyItem = text.trim().length === 0;

    if (isEmptyItem) {
        return {
            exitList: true,
            remainingPrefix: quoteAndIndent
        };
    }

    var nextMarker = getNextListMarker(marker);

    if (isTask) {
        return {
            nextPrefix: quoteAndIndent + nextMarker + spacing + "[ ] "
        };
    }

    return {
        nextPrefix: quoteAndIndent + nextMarker + spacing
    };
}

function getNextListMarker(marker) {
    var ordered = marker.match(/^(\d{1,9})([.)])$/);

    if (!ordered) {
        return marker;
    }

    var number = parseInt(ordered[1], 10);
    var suffix = ordered[2];

    return (number + 1) + suffix;
}
