(function () {
    "use strict";

    let themesRegistered = false;
    let userOverridesApplied = false;

    const themeDefinitions = {
        vscodedark: {
            monacoName: "mm-vscode-dark",
            base: "vs-dark",
            inherit: true,
            colors: {
                "editor.background": "#1E1E1E",
                "editor.foreground": "#F2F2F2",                
                "editorLineNumber.foreground": "#858585",
                "editorLineNumber.activeForeground": "#C6C6C6",
                "editorLineHighlightBackground": "#303030",
                "editorCursor.foreground": "#A7A7A7",
                "editor.selectionBackground": "#264F78",
                "editor.inactiveSelectionBackground": "#3A3D41",
                "editorWhitespace.foreground": "#515151"
            },            
            markdown: {
                heading: "569BD5",
                strong: "569BD5",
                emphasis: "C7D8F6",
                list: "6789BB",
                inlineCode: "C39D85",
                link: "CEAA5F",
                builtin: "87CEFA",
                blockquote: "608A4E",
                table: "8FB8E8"
            }
        },
        vscodelight: {
            monacoName: "mm-vscode-light",
            base: "vs",
            inherit: true,
            colors: {
                "editor.background": "#FCFCFC",
                "editor.foreground": "#222222",
                "editorLineNumber.foreground": "#8E8E8E",
                "editorLineNumber.activeForeground": "#4A4A4A",
                "editorLineHighlightBackground": "#F5F5F5",
                "editorCursor.foreground": "#000000",
                "editor.selectionBackground": "#B5D5FF",
                "editor.inactiveSelectionBackground": "#DDEAFD",
                "editorWhitespace.foreground": "#C8C8C8"
            },
            markdown: {
                heading: "800000",
                strong: "000080",
                emphasis: "333399",
                list: "0451A5",
                inlineCode: "A31515",
                link: "0A58CA",
                builtin: "008080",
                blockquote: "008000",
                table: "15538A"
            }
        },
        monokai: {
            monacoName: "mm-monokai",
            base: "vs-dark",
            inherit: true,
            colors: {
                "editor.background": "#272822",
                "editor.foreground": "#F8F8F2",
                "editorLineNumber.foreground": "#75715E",
                "editorLineNumber.activeForeground": "#CFCFC2",
                "editorLineHighlightBackground": "#3E3D32",
                "editorCursor.foreground": "#F8F8F0",
                "editor.selectionBackground": "#49483E",
                "editor.inactiveSelectionBackground": "#3B3A32",
                "editorWhitespace.foreground": "#5D5D58"
            },
            markdown: {
                heading: "66D9EF",
                strong: "A6E22E",
                emphasis: "F6D46A",
                list: "FD971F",
                inlineCode: "E6DB74",
                link: "78DCE8",
                builtin: "78DCE8",
                blockquote: "88846F",
                table: "FFC66D"
            }
        },
        darcula: {
            monacoName: "mm-darcula",
            base: "vs-dark",
            inherit: true,
            colors: {
                "editor.background": "#2B2B2B",
                "editor.foreground": "#A9B7C6",
                "editorLineNumber.foreground": "#606366",
                "editorLineNumber.activeForeground": "#AFB1B3",
                "editorLineHighlightBackground": "#323232",
                "editorCursor.foreground": "#AEAFAD",
                "editor.selectionBackground": "#214283",
                "editor.inactiveSelectionBackground": "#3A3D41",
                "editorWhitespace.foreground": "#4A4A4A"
            },
            markdown: {
                heading: "6897BB",
                strong: "FFC66D",
                emphasis: "A5C261",
                list: "9876AA",
                inlineCode: "CC7832",
                link: "4A90E2",
                builtin: "56A8F5",
                blockquote: "808080",
                table: "BBB529"
            }
        },
        twilight: {
            monacoName: "mm-twilight",
            base: "vs-dark",
            inherit: true,
            colors: {
                "editor.background": "#141414",
                "editor.foreground": "#F8F8F8",
                "editorLineNumber.foreground": "#5F5A60",
                "editorLineNumber.activeForeground": "#E0E0E0",
                "editorLineHighlightBackground": "#2F2A2F",
                "editorCursor.foreground": "#A7A7A7",
                "editor.selectionBackground": "#3C4043",
                "editor.inactiveSelectionBackground": "#31353A",
                "editorWhitespace.foreground": "#4E4B52"
            },
            markdown: {
                heading: "CDA869",
                strong: "F9EE98",
                emphasis: "DAD085",
                list: "9B859D",
                inlineCode: "CF6A4C",
                link: "7587A6",
                builtin: "9FC0E0",
                blockquote: "8F9D6A",
                table: "F99157"
            }
        },
        githubdark: {
            monacoName: "mm-github-dark",
            base: "vs-dark",
            inherit: true,
            colors: {
                "editor.background": "#0D1117",
                "editor.foreground": "#C9D1D9",
                "editorLineNumber.foreground": "#6E7681",
                "editorLineNumber.activeForeground": "#ADBAC7",
                "editorLineHighlightBackground": "#161B22",
                "editorCursor.foreground": "#58A6FF",
                "editor.selectionBackground": "#264F78",
                "editor.inactiveSelectionBackground": "#1F2A3A",
                "editorWhitespace.foreground": "#3B434B"
            },
            markdown: {
                heading: "79C0FF",
                strong: "A5D6FF",
                emphasis: "8B949E",
                list: "F2CC60",
                inlineCode: "FFA657",
                link: "58A6FF",
                builtin: "79C0FF",
                blockquote: "8B949E",
                table: "7EE787"
            }
        },
        githublight: {
            monacoName: "mm-github-light",
            base: "vs",
            inherit: true,
            colors: {
                "editor.background": "#FFFFFF",
                "editor.foreground": "#24292F",
                "editorLineNumber.foreground": "#8C959F",
                "editorLineNumber.activeForeground": "#57606A",
                "editorLineHighlightBackground": "#F6F8FA",
                "editorCursor.foreground": "#0969DA",
                "editor.selectionBackground": "#DDF4FF",
                "editor.inactiveSelectionBackground": "#EAEFF2",
                "editorWhitespace.foreground": "#D0D7DE"
            },
            markdown: {
                heading: "0550AE",
                strong: "0A3069",
                emphasis: "57606A",
                list: "953800",
                inlineCode: "CF222E",
                link: "0969DA",
                builtin: "0A7EA4",
                blockquote: "656D76",
                table: "116329"
            }
        }
    };

    const themeAliases = {
        vscodedark: "vscodedark",
        vscode: "vscodedark",
        vsdark: "vscodedark",
        darkplus: "vscodedark",
        dark: "vscodedark",
        vscodelight: "vscodelight",
        vslight: "vscodelight",
        lightplus: "vscodelight",
        light: "vscodelight",
        visualstudio: "vscodelight",
        monokai: "monokai",
        monakai: "monokai",
        darcula: "darcula",
        twilight: "twilight",
        githubdark: "githubdark",
        github: "githubdark",
        ghdark: "githubdark",
        githublight: "githublight",
        ghlight: "githublight"
    };

    function isObject(value) {
        return value && typeof value === "object" && !Array.isArray(value);
    }

    function sanitizeTokenColor(value, fallback) {
        const fallbackHex = typeof mmNormalizeColorToHex === "function"
            ? mmNormalizeColorToHex(fallback, "#FFFFFF")
            : ("#" + String(fallback || "FFFFFF").replace(/^#/, ""));
        const normalized = typeof mmNormalizeColorToHex === "function"
            ? mmNormalizeColorToHex(value, fallbackHex)
            : null;

        const withHash = normalized || fallbackHex;
        return String(withHash || "#FFFFFF").replace(/^#/, "").toUpperCase();
    }

    function sanitizeEditorColor(value, fallback) {
        if (typeof mmNormalizeColorToHex === "function") {
            const fallbackHex = mmNormalizeColorToHex(fallback, "#000000");
            return mmNormalizeColorToHex(value, fallbackHex);
        }

        if (typeof value !== "string") {
            return fallback;
        }
        return value.trim() || fallback;
    }

    function normalizeThemeName(name) {
        return (name || "")
            .toString()
            .trim()
            .toLowerCase()
            .replace(/[\s_\-\.]+/g, "");
    }

    function createMarkdownRules(markdown) {
        const defaults = themeDefinitions.vscodedark.markdown;
        const palette = {
            heading: sanitizeTokenColor(markdown && markdown.heading, defaults.heading),
            strong: sanitizeTokenColor(markdown && markdown.strong, defaults.strong),
            emphasis: sanitizeTokenColor(markdown && markdown.emphasis, defaults.emphasis),
            list: sanitizeTokenColor(markdown && markdown.list, defaults.list),
            inlineCode: sanitizeTokenColor(markdown && markdown.inlineCode, defaults.inlineCode),
            link: sanitizeTokenColor(markdown && markdown.link, defaults.link),
            builtin: sanitizeTokenColor(markdown && markdown.builtin, defaults.builtin || defaults.strong),
            blockquote: sanitizeTokenColor(markdown && markdown.blockquote, defaults.blockquote),
            table: sanitizeTokenColor(markdown && markdown.table, defaults.table)
        };

        return [
            { token: "", fontStyle: "normal" },
            { token: "support.function", foreground: palette.builtin },
            { token: "support.function.foxpro", foreground: palette.builtin },
            { token: "predefined", foreground: palette.builtin },
            { token: "predefined.foxpro", foreground: palette.builtin },
            { token: "keyword.heading.md", foreground: palette.heading, fontStyle: "bold" },
            { token: "keyword.md", foreground: palette.list },
            { token: "keyword.table.header.md", foreground: palette.table, fontStyle: "bold" },
            { token: "keyword.table.left.md", foreground: palette.table },
            { token: "keyword.table.middle.md", foreground: palette.table },
            { token: "keyword.table.right.md", foreground: palette.table },
            { token: "strong", foreground: palette.strong, fontStyle: "bold" },
            { token: "strong.md", foreground: palette.strong, fontStyle: "bold" },
            { token: "emphasis", foreground: palette.emphasis, fontStyle: "italic" },
            { token: "emphasis.md", foreground: palette.emphasis, fontStyle: "italic" },
            { token: "variable.md", foreground: palette.inlineCode },
            { token: "variable.source.md", foreground: palette.inlineCode },
            { token: "string.link.md", foreground: palette.link, fontStyle: "normal" },
            { token: "string.target.md", foreground: palette.link },
            { token: "comment.md", foreground: palette.blockquote, fontStyle: "italic" },
            { token: "escape.md", foreground: palette.strong },            
        ];
    }

    function applyThemeOverride(themeName, overrideDef) {
        if (!isObject(overrideDef)) {
            return;
        }

        const key = normalizeThemeName(themeName);
        if (!key) {
            return;
        }

        const existing = themeDefinitions[key];
        const base = existing ? existing.base : "vs-dark";
        const inherit = existing ? existing.inherit : true;
        const monacoName = existing ? existing.monacoName : ("mm-user-" + key);
        const colors = Object.assign({}, existing ? existing.colors : {});
        const markdownDefaults = existing && existing.markdown ? existing.markdown : themeDefinitions.vscodedark.markdown;
        const markdown = Object.assign({}, markdownDefaults);

        if (overrideDef.colors && isObject(overrideDef.colors)) {
            Object.keys(overrideDef.colors).forEach(function (colorKey) {
                colors[colorKey] = sanitizeEditorColor(overrideDef.colors[colorKey], colors[colorKey]);
            });
        }
        if (overrideDef.markdown && isObject(overrideDef.markdown)) {
            Object.assign(markdown, overrideDef.markdown);
        }

        const merged = {
            monacoName: typeof overrideDef.monacoName === "string" && overrideDef.monacoName ? overrideDef.monacoName : monacoName,
            base: typeof overrideDef.base === "string" && overrideDef.base ? overrideDef.base : base,
            inherit: typeof overrideDef.inherit === "boolean" ? overrideDef.inherit : inherit,
            colors: colors,
            markdown: markdown
        };

        if (Array.isArray(overrideDef.rules)) {
            merged.rules = overrideDef.rules.slice(0);
        }
        if (Array.isArray(overrideDef.additionalRules)) {
            merged.additionalRules = overrideDef.additionalRules.slice(0);
        }

        themeDefinitions[key] = merged;
        themeAliases[key] = key;

        if (Array.isArray(overrideDef.aliases)) {
            overrideDef.aliases.forEach(function (alias) {
                const normalizedAlias = normalizeThemeName(alias);
                if (normalizedAlias) {
                    themeAliases[normalizedAlias] = key;
                }
            });
        }
    }

    function applyAliasOverride(aliasName, targetThemeName) {
        const alias = normalizeThemeName(aliasName);
        const target = normalizeThemeName(targetThemeName);
        if (!alias || !target) {
            return;
        }
        themeAliases[alias] = target;
    }

    function applyUserOverrides() {
        if (userOverridesApplied) {
            return;
        }

        let overrides = null;
        try {
            overrides = window.mmMonacoThemeOverrides;
        } catch (_) {
            userOverridesApplied = true;
            return;
        }
        if (!isObject(overrides)) {
            userOverridesApplied = true;
            return;
        }

        if (isObject(overrides.themes)) {
            try {
                Object.keys(overrides.themes).forEach(function (themeKey) {
                    applyThemeOverride(themeKey, overrides.themes[themeKey]);
                });
            } catch (_) { }
        }

        if (isObject(overrides.aliases)) {
            try {
                Object.keys(overrides.aliases).forEach(function (aliasKey) {
                    applyAliasOverride(aliasKey, overrides.aliases[aliasKey]);
                });
            } catch (_) { }
        }

        userOverridesApplied = true;
    }

    function resolveThemeKey(themeName) {
        applyUserOverrides();
        const normalized = normalizeThemeName(themeName);
        let key = themeAliases[normalized];
        if (!key) {
            key = normalized.indexOf("light") > -1 ? "vscodelight" : "vscodedark";
        }
        return key;
    }

    function registerThemes(monaco) {
        applyUserOverrides();

        if (themesRegistered) {
            return;
        }

        Object.keys(themeDefinitions).forEach(function (key) {
            const def = themeDefinitions[key];
            let rules = createMarkdownRules(def.markdown);
            if (Array.isArray(def.rules)) {
                rules = def.rules.concat(rules);
            }
            if (Array.isArray(def.additionalRules)) {
                rules = rules.concat(def.additionalRules);
            }

            try {
                monaco.editor.defineTheme(def.monacoName, {
                    base: def.base,
                    inherit: def.inherit,
                    rules: rules,
                    colors: def.colors
                });
            } catch (error) {
                if (console && console.error) {
                    console.error("Failed to define Monaco theme '" + key + "'.", error);
                }
                monaco.editor.defineTheme(def.monacoName, {
                    base: "vs-dark",
                    inherit: true,
                    rules: createMarkdownRules(themeDefinitions.vscodedark.markdown),
                    colors: themeDefinitions.vscodedark.colors
                });
            }
        });

        themesRegistered = true;
    }

    window.mmMonacoThemes = {
        register: function (monacoRef) {
            const monaco = typeof monacoRef === "function" ? monacoRef() : window.monaco;
            if (!monaco || !monaco.editor || typeof monaco.editor.defineTheme !== "function") {
                return;
            }

            registerThemes(monaco);
        },
        addOrUpdateTheme: function (themeName, definition) {
            applyThemeOverride(themeName, definition);
            themesRegistered = false;
        },
        addAlias: function (aliasName, targetThemeName) {
            applyAliasOverride(aliasName, targetThemeName);
        },
        resolveThemeName: function (themeName) {
            const key = resolveThemeKey(themeName);
            const def = themeDefinitions[key] || themeDefinitions.vscodedark;
            return def.monacoName;
        }
    };
})();
