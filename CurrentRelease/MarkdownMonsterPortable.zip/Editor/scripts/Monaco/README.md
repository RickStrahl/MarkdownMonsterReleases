# Custom Monaco Distribution

This directory contains the minified AMD distribution built from the local
`monaco-editor` 0.56.0 checkout, using `monaco-editor-core` 0.56.0-dev-20260625
with the canvas-padding base and hardening patches. This is not an unmodified
public release.

The patches implement `padding.maxEditorCanvasWidth`, including text-layer and
caret clipping, content-widget visibility, edge-aligned scrollbars, GPU scissor
bounds, and sticky-scroll width updates. Markdown Monster maps its existing
centered-mode `maxWidth` setting to this option. The width now refers to the text
viewport, excluding gutters, minimap, and scrollbar; zero disables the cap.

## Rebuild

From `D:\projects\ThirdParty\monaco-editor`:

```powershell
npm run build-monaco-editor
npm run test:canvas-padding
npx playwright test --config=test/smoke/playwright.config.ts canvas-padding.test.ts --project=amd-chromium --project=amd-firefox --project=amd-webkit
```

The build applies `build/canvas-padding.patch` followed by
`build/canvas-padding-hardening.patch`, both pinned to the core version above.
It does not automatically compile the sibling VS Code checkout. The hardening
changes are backported from that source candidate. The original patch's extra
`contentRightPadding` layout field remains for compatibility with the local
prototype; upstream uses no additional public layout field.

After testing, replace the complete `vs` directory here with
`out/monaco-editor/min/vs` from that build, preserving a backup first. Also copy
the build's `LICENSE` and `ThirdPartyNotices.txt`. Do not mix files from different
Monaco builds or replace this directory with the public package without also
addressing the custom padding option.

Rebuild MM and fully restart the application. The project copies editor assets
into its output directory with `PreserveNewest`.

## Verification

The packaged AMD suite passed 15 browser tests across Chromium, Firefox, and
WebKit. MM's own editor page passed initialization, typing, centered-width,
resize, disabled-width, split-view, computed-diff, runtime diff updates, and
return-to-single-editor checks. The MM Debug build succeeded.

To repeat MM's browser integration check, serve its Editor directory on localhost
port 8574, then run `node docs/pr/canvas-padding/verify-mm.mjs` from the Monaco
checkout. Set `MM_EDITOR_URL` to use another URL. The test bypasses optional user
extensions and does not exercise the WPF/WebView2 host bridge.

Actual GPU painting, screen readers, IME, and desktop interaction still require
manual validation. GPU geometry is tested, but no WebGPU adapter was available
in the automated test environment.