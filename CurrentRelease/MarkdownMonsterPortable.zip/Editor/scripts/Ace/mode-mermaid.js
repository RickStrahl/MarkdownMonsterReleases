define("ace/mode/mermaid_highlight_rules",["require","exports","module","ace/lib/oop","ace/mode/text_highlight_rules"], function(require, exports, module){"use strict";
var oop = require("../lib/oop");
var TextHighlightRules = require("./text_highlight_rules").TextHighlightRules;
var MermaidHighlightRules = function () {
    var keywords = ("classDef|class|style|config|theme|" +
        "graph|flowchart|sequenceDiagram|classDiagram|stateDiagram-v2|quadrantChart|requirementDiagram|" +
        "erDiagram|gantt|journey|pie|xychart-beta|xychart|timeline|kanban|mindmap|treemap|architecture");
    var keywordMapper = this.createKeywordMapper({
        "keyword": keywords
    }, "identifier", true);
    this.$rules = {
        "start": [
            {
                token: "comment",
                regex: /%%.*$/
            },
            {
                token: "comment.doc", // JSON-style init directive
                regex: /%%\{.*\}%%/
            },
            {
                token: "keyword",
                regex: /\b(TB|BT|RL|LR|TD)\b/
            },
            {
                token: "support.class",
                regex: /\(\(\([^)]+\)\)\)/
            },
            {
                token: "support.class",
                regex: /\(\([^)]+\)\)/
            },
            {
                token: "support.function",
                regex: /\[\[[^\]]+\]\]/
            },
            {
                token: "entity.name.tag",
                regex: /\[[^\]]+\]/
            },
            {
                token: "entity.name.tag",
                regex: /\([^)]+\)/
            },
            {
                token: "constant.language",
                regex: /\{[^}]+\}/
            },
            {
                token: "constant.language",
                regex: /\{\{[^}]+\}\}/
            },
            {
                token: "string.regexp",
                regex: /\[\s*\/[^\/]+\/\s*\]/
            },
            {
                token: "string.regexp",
                regex: /\[\[\s*\/[^\/]+\/\s*\]\]/
            },
            {
                token: "constant.language",
                regex: /-{1,2}\.{0,1}-{1,2}>|={1,2}>{1,2}/
            },
            {
                token: "string.quoted",
                regex: /\|[^|]+\|/
            },
            {
                token: "keyword.control",
                regex: "\\b(" + keywords + ")\\b"
            },
            {
                token: "variable.parameter",
                regex: /:::[A-Za-z0-9_-]+/
            },
            {
                token: "constant.numeric",
                regex: /#[0-9a-fA-F]{3,6}\b/
            },
            {
                token: "keyword",
                regex: /\b(participant|actor|note|alt|opt|par|loop|critical|break|rect|end|section|dateFormat|title|excludes|state)\b/
            },
            {
                token: "constant.numeric",
                regex: /\b\d+(\.\d+)?\b/
            },
            {
                token: "string",
                regex: /"[^"]*"/
            },
            {
                token: "entity.name.function",
                regex: /\b[A-Za-z0-9_]+\b/
            },
            {
                token: keywordMapper,
                regex: "\\b[a-zA-Z_][a-zA-Z0-9_]*\\b"
            }
        ]
    };
    this.normalizeRules();
};
oop.inherits(MermaidHighlightRules, TextHighlightRules);
exports.MermaidHighlightRules = MermaidHighlightRules;

});

define("ace/mode/mermaid",["require","exports","module","ace/lib/oop","ace/mode/text","ace/mode/mermaid_highlight_rules"], function(require, exports, module){"use strict";
var oop = require("../lib/oop");
var TextMode = require("./text").Mode;
var MermaidHighlightRules = require("./mermaid_highlight_rules").MermaidHighlightRules;
var Mode = function () {
    this.HighlightRules = MermaidHighlightRules;
    this.$behaviour = this.$defaultBehaviour;
};
oop.inherits(Mode, TextMode);
(function () {
    this.lineCommentStart = "%%";
    this.$id = "ace/mode/mermaid";
}).call(Mode.prototype);
exports.Mode = Mode;

});
                (function() {
                    window.require(["ace/mode/mermaid"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            