var te = window.textEditor;

te.keyBindings = {
    setupKeyBindings: function () {
        setTimeout(function () {
            var kbJson = te.mm.GetKeyBindingsJson();  // sync!

            var keyBindings = JSON.parse(kbJson);

            for (var i = 0; i < keyBindings.length; i++) {
                var kb = keyBindings[i];

                if (!kb.CommandName)
                    continue;

                var handlerName = kb.CommandName[0].toLowerCase() + kb.CommandName.substr(1);
                var handler = eval("te.keyBindings." + handlerName);
                if (!handler)
                    continue;

                //console.log(kb.CommandName + ": " + kb.Key + " - " + typeof (handler));

                te.editor.commands.addCommand({
                    name: kb.Id,
                    bindKey: { win: kb.Key },
                    exec: handler,
                    hint: kb.CommandParameter
                });
            }
        }, 500);
    },
    // generic editor commands (bold, italic, href etc.) - hint is the action
    editorCommand: function () {
        var cmd = this;
        te.keyboardCommand("EditorCommand", cmd.hint);
        return null;
    },
    // donothing
    doNothing: function () { return null; },
    // this one requires explicit handling in WPF
    insertCodeBlock: function () {
        te.keyboardCommand("InsertCodeBlock");
    },
    saveDocument: function () {
        //te.mm.textbox.IsDirty(true); // force document to update
        te.keyboardCommand("SaveDocument");
    },
    newDocument: function () {
        te.keyboardCommand("NewDocument");
        // do nothing but:
        // keep ctrl-n browser behavior from happening
        // and let WPF handle the key
    },
    openDocument: function () {
        te.editor.blur(); // HACK: avoid letter o insertion into document IE bug
        te.keyboardCommand("OpenDocument");
        setTimeout(function () { te.editor.focus(); }, 20);
    },
    reloadEditor: function () {
        te.editor.blur(); // HACK: avoid letter internal F5 insertion into document IE bug
        te.keyboardCommand("ReloadEditor");
        setTimeout(function () { te.editor.focus(); }, 20);
        return null;
    },
    showHelp: function () { te.keyboardCommand("ShowHelp") },

    find: function () {
        te.editor.execCommand("find");
    },
    // find again redirect
    findNext: function () {
        te.editor.execCommand("findnext");
    },
    findPrevious: function () {
        te.editor.execCommand("findprevious");
    },
    deleteCurrentLine: function () { te.deleteCurrentLine(); },

    // try to move between tabs
    nextTab: function () { te.keyboardCommand("NextTab"); },
    previousTab: function () { te.keyboardCommand("PreviousTab"); },

    // take over Zoom keys and manually zoom
    zoomEditorDown: function () {
        te.keyboardCommand("ZoomEditorDown");
        return null;
    },
    zoomEditorUp: function () {
        te.keyboardCommand("ZoomEditorUp");
        return null;
    },


    // remove markdown formatting
    removeMarkdownFormatting: function () { te.keyboardCommand("RemoveMarkdownFormatting"); },

    // Capture paste operation in WPF to handle Images
    paste: function (editor, args) {
        te.mmAsync.PasteOperation();
    },
    paste2: function () {
        te.mmAsync.PasteOperation();
    },
    copy: function () {
        te.mmAsync.CopyOperation();
    },
    cut: function () {
        te.mmAsync.CutOperation();
    },
    nextSpellCheckError: function () {
        var pos = te.getCursorPosition();
        var markers = te.editor.session.getMarkers(true);

        var range;
        for (var key in markers) {
            range = markers[key].range;
            if (range.end.row > pos.row || range.end.row === pos.row && range.end.column > pos.column) {
                te.editor.scrollToLine(range.end.row);
                var sel = te.editor.getSelection();
                sel.setSelectionRange(range);
                return;
            }
        }

        if (te.editor.renderer.getLastVisibleRow() >= te.editor.session.getLength() - 1)
            return;

        te.editor.gotoPageDown();
        sc.contentModified = true;
        sc.spellCheck();

        setTimeout(te.keyBindings.nextSpellCheckError, 200);
    },
    previousSpellCheckError: function () {
        var pos = te.getCursorPosition();
        var markers = te.editor.session.getMarkers(true);

        var keys = [];
        for (var key in markers)
            keys.push(key);

        while (true) {
            var key = keys.pop();
            if (!key)
                break;

            var range = markers[key].range;
            if (range.end.row < pos.row || range.end.row === pos.row && range.end.column < pos.column) {
                te.editor.scrollToLine(range.end.row);
                te.setSelectionRange(range);
                return;
            }
        }

        if (te.editor.renderer.getFirstVisibleRow() < 2)
            return;

        te.editor.gotoPageUp();
        sc.contentModified = true;
        sc.spellCheck();
        setTimeout(te.keyBindings.nextSpellCheckError, 200);
    }
};


// Tab Completions for bullets
setTimeout(function () {

    if (te.settings.enableListAutoCompletion) {
        var editor = te.editor;        
        var session = editor.session;
        var Range = ace.Range;              

        // Utility function to check if a line starts with a bullet/numbered list marker.
        function isListLine(line) {
            return /^\s*(?:[-+*]|\d+\.)\s+/.test(line);
        }
        function isNumberedListLine(line) {
            return /^\s*(?:\d+\.)\s+/.test(line);
        }

        editor.commands.addCommand({
            name: 'handleBulletTab',
            bindKey: { win: 'Tab', mac: 'Tab' },
            exec: function (editor) {               
                var tabString = session.getTabString();
                var ranges = editor.selection.getAllRanges();
                // Check if every selected line is a list item.
                var isList = true;
                ranges.forEach(function (range) {
                    for (var i = range.start.row; i <= range.end.row; i++) {
                        var line = session.getLine(i);
                        if (!isListLine(line)) {
                            isList = false;
                            break;
                        }
                    }
                });

                if (!isList) return false; // default behavior

                // Insert the tab string at the beginning of each selected line.
                ranges.forEach(function (range) {
                    for (var i = range.start.row; i <= range.end.row; i++) {
                        session.insert({ row: i, column: 0 }, tabString);
                    }
                });

                renumberBullets();
                return true;
            },
            multiSelectAction: "forEach"
        });

        // Optional: Add command to handle shift+tab to decrease indentation
        editor.commands.addCommand({
           name: 'handleBulletShiftTab',
           bindKey: { win: 'Shift-Tab', mac: 'Shift-Tab' },
           exec: function (editor) {
               var tabString = session.getTabString();
               var ranges = editor.selection.getAllRanges();
               var isList = true;

               ranges.forEach(function (range) {
                   for (var i = range.start.row; i <= range.end.row; i++) {
                       var line = session.getLine(i);
                       if (!isListLine(line)) {
                           isList = false;
                           break;
                       }
                   }
               });

               if (!isList) return false; // default behavior
               
                // Remove one indent (tab string) from the start of each selected line if present.
                ranges.forEach(function (range) {
                    for (var i = range.start.row; i <= range.end.row; i++) {
                        var line = session.getLine(i);
                        if (line.indexOf(tabString) === 0) {                          
                            var range = new Range(i, 0, i, tabString.length);
                            session.replace(range, "");
                        }
                    }
                });

               renumberBullets();
               return true;
            },
           multiSelectAction: "forEach"
        });

        function renumberBullets() {
            var session = editor.session;
            var numLines = session.getLength();
            var stack = []; // Stack to track nesting levels: each element is {indent: string, counter: number}

            for (var i = 0; i < numLines; i++) {
                var line = session.getLine(i);
                // Look for a numbered bullet (e.g. "  3. ").
                var match = line.match(/^(\s*)(\d+)(\.)\s+/);
                if (match) {
                    var indent = match[1];
                    var currentIndentLen = indent.length;
                    var newNumber;
                    if (stack.length === 0) {
                        // Start a new top-level list.
                        stack.push({ indent: indent, counter: 1 });
                        newNumber = 1;
                    } else {
                        var topIndentLen = stack[stack.length - 1].indent.length;
                        if (currentIndentLen === topIndentLen) {
                            // Same level: increment the counter.
                            stack[stack.length - 1].counter++;
                            newNumber = stack[stack.length - 1].counter;
                        } else if (currentIndentLen > topIndentLen) {
                            // New nested level: start counter at 1.
                            stack.push({ indent: indent, counter: 1 });
                            newNumber = 1;
                        } else {
                            // Exiting to an outer level: pop until we find a matching level.
                            while (stack.length && stack[stack.length - 1].indent.length > currentIndentLen) {
                                stack.pop();
                            }
                            if (stack.length && stack[stack.length - 1].indent.length === currentIndentLen) {
                                stack[stack.length - 1].counter++;
                                newNumber = stack[stack.length - 1].counter;
                            } else {
                                // If no matching level is found, start a new one.
                                stack.push({ indent: indent, counter: 1 });
                                newNumber = 1;
                            }
                        }
                    }
                    // Build the new bullet prefix.
                    var prefix = indent + newNumber + ". ";
                    if (match[0] !== prefix) {
                        var rest = line.substring(match[0].length);
                        var newLine = prefix + rest;
                        // Replace the entire line using session.replace with a range covering the whole line.
                        var range = new Range(i, 0, i, line.length);
                        session.replace(range, newLine);
                    }
                } else {
                    // When a non-numbered list line is encountered, reset the stack.
                    stack = [];
                }
            }
        }
    }
}, 600);
