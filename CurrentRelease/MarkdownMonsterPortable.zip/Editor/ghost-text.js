
// Ghost text state
let ghostTextContent = '';
let ghostTextPosition = null;
let ghostTextTimeout = null;

class GhostTextManager {
    constructor() {
        // properties
        this.textEditor = window.textEditor; // Reference to the main editor instance   
        this.editor = this.textEditor.editor;             
        this.textEditor.ghostText = this; // Store reference for global access

        this.setupEventHandlers();
    }

    setupEventHandlers() {
        
        // Handle Tab key for accepting ghost text
        this.editor.commands.addCommand({
            name: 'acceptGhostText',
            bindKey: 'Tab',
            exec: (editor) => {
                if (ghostTextContent && ghostTextPosition) {
                    this.acceptGhostText();
                    return true; // Prevent default tab behavior
                }
                return false; // Allow normal tab behavior 
            }
        });

        
        if (!this.textEditor.settings.noAiAutoSuggestions || !this.textEditor.settings.isAiEnabled) {

            // Handle ctrl-space autosuggestions for triggering ghost text
            // Calls into .NET to perform the AI completion
            // to inject as ghost text (calls back to showGhostText)
            this.editor.commands.addCommand({
                name: 'triggerGhostTextSuggestions',
                bindKey: 'Ctrl-Space',
                exec: async (editor) => {                    
                    this.textEditor.mmAsync.RequestGhostText();
                }
            });
        }

        // Clear ghost text on any text or mouse input
        this.editor.on('change', (delta) => {
            if (ghostTextContent && delta.action === 'insert' && !this.isInternalOperation) {
                this.clearGhostText();
            }

            // Trigger ghost text on space after delay
            // if (delta.action === 'insert' && delta.lines && delta.lines.join('').includes(' ')) {
            //     this.scheduleGhostText();
            // }
        });

        
        // Handle Escape key EXPLICITLY for dismissing ghost text
        // as it isn't handled by the change handler
        this.editor.commands.addCommand({
            name: 'dismissGhostText',
            bindKey: 'Escape',
            exec: (editor) => {
                if (ghostTextContent && ghostTextPosition) {
                    this.clearGhostText();
                    return true;
                }
                return false;
            }
        });

        // Clear ghost text when cursor moves
        this.editor.on('changeSelection', () => {
            if (ghostTextContent && !this.isInternalOperation) {
                this.clearGhostText();
            }
        });

        // Update ghost text position on scroll
        this.editor.on('changeScrollTop', () => {
            if (ghostTextContent && ghostTextPosition) {
                this.updateGhostTextPosition();
            }
        });

        this.editor.on('changeScrollLeft', () => {
            if (ghostTextContent && ghostTextPosition) {
                this.updateGhostTextPosition();
            }
        });
    }

    // scheduleGhostText() {

    //     // // Clear any existing timeout
    //     // if (ghostTextTimeout) {
    //     //     clearTimeout(ghostTextTimeout);
    //     // }

    //     // // Schedule ghost text to appear after 2 seconds
    //     // ghostTextTimeout = setTimeout(() => {
    //     //     if (!ghostTextContent || !ghostTextPosition) {
    //     //         this.suggestGhostText();
    //     //     }
    //     //     ghostTextTimeout = null;
    //     // }, 2000);
    // }

    /*
        Displays ghost text in the editor at the specified position.
        Defers to the editor to insert the text which in turn
        calls the LLM to generate the in-context ghost text.

        This is called by the .NET code that is triggered by
        the Ctrl-Space key combination (or auto-suggest?)
    */
    showGhostText(text, position = null) {     
        // Use current cursor position if none specified
        if (!position) {
            position = this.editor.getCursorPosition();
        }
        
        // Clear any existing ghost text
        this.clearGhostText();
    
        ghostTextContent = text;                
        ghostTextPosition = position;

        // Call ACE ghostText function
        this.editor.setGhostText(text, position);       
    }

    /*
        Removes the ghost text from the editor and resets the state.
    */
    clearGhostText() {        
        this.editor.removeGhostText();

        // Clean up state
        ghostTextContent = '';
        ghostTextPosition = null;        
    }

    
    /*
       Accepts the ghost text and inserts it at the stored position.
    */
    acceptGhostText() {
        if (!ghostTextContent || !ghostTextPosition) return;

        // Insert the ghost text at the stored position
        this.isInternalOperation = true;
        this.editor.session.insert(ghostTextPosition, ghostTextContent.substring(1));  // strip of leading /n
        this.isInternalOperation = false;

        // Clean up
        this.clearGhostText();

        // Focus back to editor
        this.editor.focus();
    }
}



// Initialize ghost text manager
$(  ()=> {
    // have to ensure the textEditor has initialized - it takes a while!
    setTimeout(() => {
        if (window.textEditor.mainEditor) {
            window.ghostManager = new GhostTextManager(window.textEditor.editor);
        }
    },1000);
});


//// Global functions for demo buttons
//function showGhostText(text) {
//    ghostManager.showGhostText(text);
//}

//function clearGhostText() {
//    ghostManager.clearGhostText();
//}

//// Focus the editor
//editor.focus();
