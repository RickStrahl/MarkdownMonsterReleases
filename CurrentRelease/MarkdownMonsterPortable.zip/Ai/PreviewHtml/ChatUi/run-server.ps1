# PowerShell script to run West Wind's LiveReloadServer for Chat UI development
# Allows running offline without running through Markdown Mosnter
#
# Requires LiveReloadServer dotnet tool to be installed globally
# https://github.com/RickStrahl/LiveReloadServer

param(
    [string]$Port = "5200",
    [string]$Path = ".",
    [switch]$Help
)

if ($Help) {
    Write-Host "Chat UI Development Server Runner" -ForegroundColor Green
    Write-Host ""
    Write-Host "Usage: .\run-server.ps1 [-Port <port>] [-Path <path>] [-Help]"
    Write-Host ""
    Write-Host "Parameters:"
    Write-Host "  -Port <port>    Port number to run server on (default: 5200)"
    Write-Host "  -Path <path>    Path to serve files from (default: current directory)"
    Write-Host "  -Help          Show this help message"
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  .\run-server.ps1                    # Run on port 5200"
    Write-Host "  .\run-server.ps1 -Port 8080         # Run on port 8080"
    Write-Host "  .\run-server.ps1 -Path ./dist       # Serve from dist folder"
    Write-Host ""
    exit
}

# Check if LiveReloadServer is installed
$liveReloadServer = Get-Command "LiveReloadServer" -ErrorAction SilentlyContinue

if (-not $liveReloadServer) {
    Write-Host "LiveReloadServer not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install LiveReloadServer first:" -ForegroundColor Yellow
    Write-Host "1. Download from: https://github.com/RickStrahl/LiveReloadServer/releases"
    Write-Host "2. Or install via Chocolatey: choco install livereloadserver"
    Write-Host "3. Or install via .NET tool: dotnet tool install -g LiveReloadServer"
    Write-Host ""
    exit 1
}

# Resolve absolute path
$absolutePath = Resolve-Path $Path -ErrorAction SilentlyContinue
if (-not $absolutePath) {
    Write-Host "Path not found: $Path" -ForegroundColor Red
    exit 1
}

# Display startup information
Write-Host "🚀 Starting Chat UI Development Server" -ForegroundColor Green
Write-Host "📁 Serving from: $absolutePath" -ForegroundColor Cyan
Write-Host "🌐 Port: $Port" -ForegroundColor Cyan
Write-Host "🔗 URL: http://localhost:$Port" -ForegroundColor Yellow
Write-Host ""
Write-Host "Features enabled:" -ForegroundColor White
Write-Host "  ✅ Live reload on file changes" -ForegroundColor Green
Write-Host "  ✅ Static file serving" -ForegroundColor Green
Write-Host "  ✅ Auto browser opening" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Gray
Write-Host "----------------------------------------" -ForegroundColor Gray

# Start the LiveReloadServer
try {
    & LiveReloadServer --port $Port -usessl --webroot $absolutePath --open --watch --verbose --BrowserUrl "ChatUi.html"
}
catch {
    Write-Host "Error starting LiveReloadServer: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Server stopped." -ForegroundColor Yellow
