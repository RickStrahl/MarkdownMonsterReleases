// Sample data for the Chat UI
export const sampleData = {
    conversation: [
        {
            id: "_" + new Date().getTime(),
            type: 'assistant',
            content: '<b>Hello</b>. How can I help you today?',
            timestamp: new Date(Date.now()) // 5 minutes ago
        },

        //      {
        //     id: "_" + new Date().getTime(),
        //     type: 'user',
        //     content: 'Tell me about the history of West Berlin snd givre me s lot of detail\n\nMotr info to follow.',
        //     timestamp: new Date(Date.now()) // 5 minutes ago
        // }
    ]
    
   
};

// Export individual arrays for easier access
export const { conversation, contextFiles, settings } = sampleData;
