// Sample data for the Chat UI
export const sampleData = {
    conversation: [
        {
            id: 'zxaswesw',
            type: 'assistant',
            content: '<b>Hello</b>. How can I help you today?',
            timestamp: new Date(Date.now()) // 5 minutes ago
        }
    ]
    
   
};

// Export individual arrays for easier access
export const { conversation, contextFiles, settings } = sampleData;
