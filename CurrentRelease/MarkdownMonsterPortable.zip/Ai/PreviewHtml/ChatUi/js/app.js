// Main Vue.js application
import { sampleData } from './data.js';
import { utils } from './utils.js';

const { createApp } = Vue;

window.vm = {};
window.chatUi = {};


createApp({
    data() {
        vm =  {
            // Core data
            conversation: [...sampleData.conversation],
                        
            // UI state
            isLoading: false,
            
            // File upload
            nextFileId: 3, // Starting from 3 since we have 2 sample files

            busy: false
        };
        window.chatUi = this;
        return vm;
    },
    
    methods: {
        addMessage(id, text, isAssistant = false) {
            const msg = {
                id: id,                
                type: isAssistant ? 'assistant' : 'user',
                content: text,
                timestamp: new Date(Date.now()) // 5 minutes ago
            };
            this.conversation.push(msg);

            vm.busy = isAssistant ? false : true;  // user message sets busy

            // scroll to the bottom based on the new message id
            setTimeout(() => {
                if(isAssistant)
                    document.getElementById(id).scrollIntoView({ behavior: 'smooth' });                
                else 
                {
                    window.scrollTo({
                        top: document.body.scrollHeight,
                        behavior: 'smooth'
                    });
                }
            },110);
            return true;
        },
        
        clearConversation() {
            this.conversation = [];
            return true;            
        },

        copyAsMarkdown(id, pasteIntoDocument = false) {

            if (!pasteIntoDocument)
                window.chrome.webview.hostObjects.dotnet.CopyAsMarkdownCallback(id);
            else
                window.chrome.webview.hostObjects.dotnet.PasteAsMarkdownCallback(id);
        },
        


        exportConversation() {
            const format = confirm('Export as JSON? (Cancel for Markdown)') ? 'json' : 'markdown';
            utils.exportConversation(this.conversation, format);
        },
        
        formatTime(timestamp) {
            return utils.formatTime(timestamp);
        },
        
        renderMarkdown(text) {
            return utils.renderMarkdown(text);
        }
    },
    
    // // Integration API for external applications
    // provide() {
    //     return {
    //         // Methods that external applications can call
    //         chatAPI: {
    //             // Add message to conversation
    //             addMessage: (content, type = 'user') => {
    //                 const message = {
    //                     id: utils.generateId(),
    //                     type: type,
    //                     content: content,
    //                     timestamp: new Date()
    //                 };
    //                 this.conversation.push(message);
    //                 return message.id;
    //             },
                
    //             // Get conversation data
    //             getConversation: () => {
    //                 return JSON.parse(JSON.stringify(this.conversation));
    //             },
                
    //             // Get last AI response
    //             getLastResponse: () => {
    //                 const aiMessages = this.conversation.filter(m => m.type === 'ai');
    //                 return aiMessages.length > 0 ? aiMessages[aiMessages.length - 1] : null;
    //             },
                
    //             // Set context files
    //             setContextFiles: (files) => {
    //                 this.contextFiles = files.map(file => ({
    //                     ...file,
    //                     id: file.id || utils.generateId()
    //                 }));
    //             },
                
    //             // Get context files
    //             getContextFiles: () => {
    //                 return JSON.parse(JSON.stringify(this.contextFiles));
    //             },
                
    //             // Set system prompt
    //             setSystemPrompt: (prompt, enabled = true) => {
    //                 this.settings.systemPrompt = prompt;
    //                 this.settings.systemPromptEnabled = enabled;
    //             },
                
    //             // Clear conversation
    //             clear: () => {
    //                 this.conversation = [];
    //             },
                
    //             // Export data
    //             export: (format = 'json') => {
    //                 return utils.exportConversation(this.conversation, format);
    //             }
    //         }
    //     };
    //},
    
    mounted() {
        // Expose API to global scope for external integration
        window.ChatUI = this.chatAPI;
        
        // Auto-scroll to bottom on mount
        this.$nextTick(() => {
            utils.scrollToBottom(this.$refs.conversation);
        });
        
        console.log('Chat UI loaded successfully!');
        console.log('API available at window.ChatUI');
    }
}).mount('#app');
