// Main Vue.js application
import { sampleData } from './data.js';
import { utils } from './utils.js';

const { createApp } = Vue;

window.vm = {};
window.chatUi = {};


createApp({
    data() {
        window.vm =  {
            // Core data
            conversation: [...sampleData.conversation],
                        
            // UI state
            isLoading: false,
            
            // File upload
            nextFileId: 3, // Starting from 3 since we have 2 sample files

            busy: false
        };
        window.chatUi = this;
        return vm;
    },
    
    methods: {
        addMessage(id, text, isAssistant = false, isFile = false, isImage = false, data = null, stats = null) {
        
            const msg = {
                id: id,                
                type: isAssistant ? 'assistant' : 'user',
                content: text,
                data: data,
                isFile: isFile,
                isImage: isImage,
                timestamp: new Date(Date.now()), // 5 minutes ago
                stats: stats
            };
            this.conversation.push(msg);

            this.busy = isAssistant ? false : true;  // user message sets busy


            // scroll to the bottom based on the new message id
            setTimeout(() => {
                highlightCode(); // re-highlight code blocks when new message is added

                const element = document.getElementById(id);
                if (element) {
                    element.scrollIntoView({ behavior: "smooth"}); //, block: "start", container: "nearest"});
                }   
            },80);

            return true;
        },


        setBusy(busy) {
            this.busy = busy;
            return true;
        },
        getBusy() {
            return this.busy;
        },

        clearConversation() {
            this.conversation = [];
            return true;            
        },

        copyAsMarkdown(id, pasteIntoDocument = false) {

            if (!pasteIntoDocument)
                window.chrome.webview.hostObjects.dotnet.CopyAsMarkdownCallback(id);
            else
                window.chrome.webview.hostObjects.dotnet.PasteAsMarkdownCallback(id);
        },
        


        exportConversation() {
            const format = confirm('Export as JSON? (Cancel for Markdown)') ? 'json' : 'markdown';
            utils.exportConversation(this.conversation, format);
        },
        
        formatTime(timestamp) {
            return utils.formatTime(timestamp);
        },
        
        renderMarkdown(text) {
            return utils.renderMarkdown(text);
        },

        sampleRequests() {
            var msgs = [
                {
                    type: 'user',
                    text: 'Hello, how are you?',
                    data: null,
                    isFile: false,
                    isImage: false
                },
                {
                    type: 'user',
                    text: "icon.png",
                    isAssistant: false,
                    isFile: false,
                    isImage: true,
                    data: "https://west-wind.com/wconnect/images/icon.png"
                },
                {
                    type: 'assistant',
                    text: 'I am fine, thank you! How can I assist you today?',
                    isAssistant: true
                }

            ];

        
        var index = 0;
        setInterval( () => { 
            console.log('looping');
            var msg = msgs[index];
            
                        
            this.addMessage("_" + new Date().getTime(), msg.text, msg.isAssistant,msg.isFile, msg.isImage, msg.data);
            index++;
        }, 1000);
        }


    },
    
    
    mounted() {
        // Expose API to global scope for external integration
        window.ChatUI = this.chatAPI;
        
        // Auto-scroll to bottom on mount
        this.$nextTick(() => {
            utils.scrollToBottom(this.$refs.conversation);
        });
        
        console.log('Chat UI loaded successfully!');
        console.log('API available at window.ChatUI');

        // this.sampleRequests();       
    }
}).mount('#app');


window.highlightCode = function(lineno) {
    var pres = document.querySelectorAll("pre>code");
    if (pres.length < 1) return;

    // Try to find lineno in doc - if lineno is passed
    // and render only those plus padding above and below
    var linePos = 0;

    // // special handling for more than 200 code blocks
    // // render only  what's in the viewport
    // if (lineno && pres.length > 200) {
    //     var $el = $("#pragma-line-" + lineno);
    //     if ($el.length < 1) {
    //         for (var j = 0; j < 10; j++) {
    //             if (lineno - j < 0)
    //                 break;
    //             var $el = $("#pragma-line-" + (lineno - j) );
    //             if ($el.length > 0)
    //                 break;
    //         }
    //         if ($el.length < 1) {
    //             for (var k = 0; k < 10; k++) {
    //                 var $el = $("#pragma-line-" + (lineno + k) );
    //                 if ($el.length > 0)
    //                     break;
    //             }
    //         }
    //     }
    //     if ($el.length > 0) {
    //         linePos = $el.position().top;
    //     }
    // }

    for (var i = 0; i < pres.length; i++) {
        var block = pres[i];
        var $code = $(block);
        // too many code blocks to render or text/plain styles - just style
        if ((pres.length > 400) ||
            $code.hasClass("language-text") ||
            $code.hasClass("language-plain")) {
                $code.addClass("hljs");
                continue;
        }

        // no language specified - don't render'
        if (block.classList.toString().indexOf("language-") < 0) {
            $code.addClass("hljs");
            continue;
        }

        hljs.highlightBlock(block);
    }

    // add the code snippet syntax and code copying
    if (window.highlightJsBadge)
        window.highlightJsBadge();
}



// Theme management
window.renderTheme = "dark";

// saved Css link element
var lightLink = null;   

function setTheme(theme) {    
    if (!theme) {
        theme = localStorage.getItem('theme');
        if (!theme) {
            theme = window.renderTheme;
        }
    }
    else {
        theme = localStorage.setItem('theme',theme);
    }

    if (theme === 'dark') {
        enableDarkTheme();
    } else {
        disableDarkTheme();
    }
}


function enableDarkTheme() {

    if (lightLink) {
        if(typeof lightLink.remove === "function")
            lightLink.remove();
        lightLink = null;

        const link = document.getElementById("ThemeCss");
        if (link) {
            const href = link.getAttribute("href");
            link.href = href.replace('theme-light.css', 'theme.css');
        }
    }
    setThemeIcon(false);
}

function disableDarkTheme() {
    if (!lightLink) {
        let link = document.getElementById("AppCss").getAttribute("href");
        lightLink = document.createElement("link");
        lightLink.rel = "stylesheet";
        lightLink.href = link.replace('styles.css', 'styles-light.css');
        lightLink.id = "lightStylesheet";
        document.head.appendChild(lightLink);   
        
        link = document.getElementById("ThemeCss");
        const href = link.getAttribute("href");
        link.href = href.replace('theme.css', 'theme-light.css');
    }
    else {
        link = document.getElementById("ThemeCss");
        const href = link.getAttribute("href");
        link.href = href.replace('theme-light.css', 'theme.css');        
    }

    setThemeIcon(true);
}

window.toggleTheme = function() {
    if (!lightLink) {        
        disableDarkTheme();
        localStorage.setItem('theme', 'light');        
    } else {
        enableDarkTheme();
        localStorage.setItem('theme', 'dark');
    }
}
function setThemeIcon(isDark) {
    setTimeout(()=> {
        const icon = document.getElementById('themeToggleIcon');
        const btn = document.getElementById('themeToggleBtn');        
        if (icon && btn) {
            if (!isDark) {
                icon.className = 'fad fa-moon text-warning';
                btn.setAttribute('aria-label', 'Switch to light theme');
                btn.title = 'Dark Mode - Click to switch to light mode';
                
            } else {
                icon.className = 'fa fa-sun text-warning';
                btn.setAttribute('aria-label', 'Switch to dark mode');
                btn.title = 'Light Mode - Click to switch to dark mode';
                
            }
        }
    },25);
}
setTheme();
