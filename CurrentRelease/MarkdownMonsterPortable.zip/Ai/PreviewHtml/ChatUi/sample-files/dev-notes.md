# Chat UI Development Notes

## Component Architecture

### Core Components
- **Chat Container** - Main conversation display
- **Input Panel** - User input controls
- **Context Panel** - File management
- **Message Components** - User/AI message rendering

### Data Flow
1. User input → Vue reactive data
2. Message processing → Conversation array
3. File upload → Context files array
4. Rendering → Markdown parsing → HTML display

## Integration Points

### External API Surface
The Chat UI exposes a global `window.ChatUI` object with methods:

```javascript
// Add message programmatically
ChatUI.addMessage("Hello from external app", "user");

// Get conversation data
const conversation = ChatUI.getConversation();

// Set context files from external source
ChatUI.setContextFiles([
  { name: "doc.md", content: "# Document content" }
]);

// Set system prompt
ChatUI.setSystemPrompt("You are a specialized assistant");

// Export conversation
ChatUI.export("json"); // or "markdown"
```

### Data Structures

#### Message Object
```javascript
{
  id: "unique_id",
  type: "user" | "ai",
  content: "message content",
  timestamp: Date
}
```

#### Context File Object
```javascript
{
  id: "unique_id",
  name: "filename.md",
  path: "./path/to/file",
  content: "file content",
  size: 1024,
  type: "md"
}
```

## Styling Notes

### CSS Variables
- Uses CSS custom properties for theming
- CoPilot-inspired color scheme
- Responsive design breakpoints
- Dark theme optimized

### Component Classes
- `.message-user` - User messages (blue theme)
- `.message-ai` - AI messages (dark theme)
- `.context-panel` - File management sidebar
- `.input-container` - Bottom input area

## Performance Considerations

### Optimizations Implemented
- Virtual scrolling for large conversations
- Debounced input handling
- Lazy markdown rendering
- File size validation
- Memory-efficient file handling

### Future Enhancements
- Message virtualization for 1000+ messages
- Incremental markdown parsing
- WebWorker for heavy processing
- IndexedDB for conversation persistence

## Security Notes

### Current Measures
- File type validation
- Content sanitization
- XSS prevention in markdown rendering
- File size limits

### Production Recommendations
- CSP headers
- File upload virus scanning
- Rate limiting
- Authentication integration
- HTTPS enforcement

## Browser Compatibility

### Supported Browsers
- Chrome 88+
- Firefox 85+
- Safari 14+
- Edge 88+

### Required Features
- ES6 Modules
- CSS Grid
- Fetch API
- File API
- Vue 3 compatibility

## Development Workflow

### Local Testing
1. Use LiveReloadServer for development
2. Test file upload functionality
3. Verify markdown rendering
4. Check responsive design
5. Test external API integration

### Deployment Checklist
- [ ] Minify CSS/JS for production
- [ ] Configure proper MIME types
- [ ] Set up HTTPS
- [ ] Configure CSP headers
- [ ] Test cross-browser compatibility
- [ ] Validate accessibility features
