# API Specification

## Authentication

All API endpoints require authentication using Bearer tokens.

### Getting a Token
```bash
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "your_password"
}
```

### Using the Token
```bash
Authorization: Bearer <your_token_here>
```

## Rate Limiting

API calls are rate limited to prevent abuse:

- **Standard endpoints**: 100 requests per minute per API key
- **Heavy operations**: 10 requests per minute per API key
- **Bulk operations**: 5 requests per minute per API key
- **Daily limit**: 10,000 requests per day per API key

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Request limit per window
- `X-RateLimit-Remaining`: Requests remaining in current window
- `X-RateLimit-Reset`: Time when the rate limit resets

## Request/Response Format

### Content Type
All requests should use `application/json` content type.

### Response Structure
```json
{
  "success": true,
  "data": {},
  "message": "Operation completed successfully",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### Error Response Structure
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {}
  },
  "timestamp": "2024-01-01T00:00:00Z"
}
```

## Error Handling

### HTTP Status Codes

- **200 OK** - Request successful
- **201 Created** - Resource created successfully
- **400 Bad Request** - Invalid request data
- **401 Unauthorized** - Authentication required
- **403 Forbidden** - Insufficient permissions
- **404 Not Found** - Resource not found
- **409 Conflict** - Resource already exists
- **422 Unprocessable Entity** - Validation errors
- **429 Too Many Requests** - Rate limit exceeded
- **500 Internal Server Error** - Server error

### Error Codes

| Code | Description |
|------|-------------|
| `VALIDATION_ERROR` | Input validation failed |
| `AUTH_REQUIRED` | Authentication required |
| `INSUFFICIENT_PERMISSIONS` | User lacks required permissions |
| `RESOURCE_NOT_FOUND` | Requested resource doesn't exist |
| `DUPLICATE_RESOURCE` | Resource already exists |
| `RATE_LIMIT_EXCEEDED` | Too many requests |
| `SERVER_ERROR` | Internal server error |

## Pagination

Large result sets are paginated:

### Request Parameters
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 20, max: 100)
- `sort` - Sort field
- `order` - Sort direction (asc/desc)

### Response Format
```json
{
  "success": true,
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8,
    "hasNext": true,
    "hasPrev": false
  }
}
```

## Filtering and Search

### Query Parameters
- `search` - Text search across relevant fields
- `filter[field]` - Filter by specific field value
- `date_from` - Filter from date (ISO format)
- `date_to` - Filter to date (ISO format)

### Example
```
GET /api/users?search=john&filter[status]=active&date_from=2024-01-01
```

## Webhooks

The API supports webhooks for real-time notifications:

### Supported Events
- `user.created`
- `user.updated`
- `user.deleted`
- `content.created`
- `content.updated`
- `file.uploaded`

### Webhook Payload
```json
{
  "event": "user.created",
  "data": {},
  "timestamp": "2024-01-01T00:00:00Z",
  "signature": "sha256=..."
}
```

## SDK and Libraries

Official SDKs are available for:
- JavaScript/Node.js
- Python
- PHP
- Go
- Ruby

## Support

For API support, please contact:
- Email: api-support@example.com
- Documentation: https://docs.example.com
- Status Page: https://status.example.com
